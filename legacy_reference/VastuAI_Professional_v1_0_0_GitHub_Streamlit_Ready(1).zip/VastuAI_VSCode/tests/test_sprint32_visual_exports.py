from __future__ import annotations

import io
import json
import zipfile

from services.chart_service import build_direction_wheel_png, build_room_scores_png, direction_balance
from services.export_service import build_export_bundle, to_direction_balance_csv_bytes, to_json_bytes, to_room_scores_csv_bytes
from services.pdf_service import build_pdf


DETAILS = [
    {"area": "Main entrance", "direction": "North", "score": 9, "severity": "Low", "status": "Strong", "rationale": "Good placement"},
    {"area": "Kitchen", "direction": "South-East", "score": 8, "severity": "Low", "status": "Good", "rationale": "Preferred zone"},
    {"area": "Master bedroom", "direction": "South-West", "score": 7, "severity": "Medium", "status": "Acceptable", "rationale": "Stable zone"},
]
PAYLOAD = {"property_name": "Sample Residence", "flat_number": "A-101", "owner_name": "Test Owner"}
RESULT = {
    "final_result": {"score": 8.1, "rating": "Good", "basis": "Combined"},
    "vastu_result": {"score": 8.0, "grade": "A", "coverage": 80, "confidence": "High", "details": DETAILS},
    "numerology_result": {"score": 8.2, "coverage": 90},
    "recommendation_result": {"decision": "Proceed", "confidence": "High", "critical_issue_count": 0, "actions": []},
    "explanation": "A balanced sample assessment.",
}


def test_direction_balance_uses_all_eight_directions():
    rows = direction_balance(DETAILS)
    assert len(rows) == 8
    north = next(row for row in rows if row["direction"] == "North")
    assert north["average_score"] == 9
    assert north["room_count"] == 1


def test_chart_pngs_are_generated():
    assert build_direction_wheel_png(DETAILS).startswith(b"\x89PNG")
    assert build_room_scores_png(DETAILS).startswith(b"\x89PNG")


def test_visual_pdf_and_export_bundle():
    pdf = build_pdf(PAYLOAD, RESULT)
    assert pdf.startswith(b"%PDF")
    assert len(pdf) > 10_000
    bundle = build_export_bundle(PAYLOAD, RESULT, build_pdf, "Sample report")
    with zipfile.ZipFile(io.BytesIO(bundle)) as archive:
        names = set(archive.namelist())
        assert "VastuAI_Professional_Report.pdf" in names
        assert "directional_balance_wheel.png" in names
        assert "room_scores.png" in names
        assert "room_scores.csv" in names
        assert "direction_balance.csv" in names


def test_enriched_data_exports():
    assert b"Main entrance" in to_room_scores_csv_bytes(RESULT)
    assert b"North" in to_direction_balance_csv_bytes(RESULT)
    data = json.loads(to_json_bytes(PAYLOAD, RESULT))
    assert "report_visuals" in data
    assert len(data["report_visuals"]["direction_balance"]) == 8
