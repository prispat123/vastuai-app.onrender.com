from agents.recommendation_agent import recommendation_agent


def test_recommendation_builds_priority_actions():
    state = {
        "final_result": {"score": 6.2},
        "vastu_result": {
            "score": 6.0,
            "confidence": "High",
            "details": [
                {
                    "area": "Kitchen",
                    "direction": "North-East",
                    "score": 2,
                    "severity": "Critical",
                    "rationale": "Traditionally discouraged.",
                    "non_structural_remedy": "Use a practical non-structural measure.",
                    "structural_remedy": "Consult an architect.",
                }
            ],
            "strengths": ["Entrance is supportive."],
            "cautions": ["Kitchen requires review."],
        },
        "numerology_result": {"score": 7.0, "confidence": "Moderate", "strengths": [], "cautions": []},
    }
    result = recommendation_agent(state)["recommendation_result"]
    assert result["decision"] == "Proceed with caution"
    assert result["critical_issue_count"] == 1
    assert result["actions"][0]["area"] == "Kitchen"


def test_recommendation_handles_single_module():
    state = {
        "final_result": {"score": 8.0},
        "vastu_result": {"score": 8.0, "confidence": "High", "details": [], "strengths": [], "cautions": []},
        "numerology_result": {},
    }
    result = recommendation_agent(state)["recommendation_result"]
    assert "Vastu" in result["synergy_notes"][0]
