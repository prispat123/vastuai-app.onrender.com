from io import BytesIO
from unittest.mock import patch

from PIL import Image

from services.floorplan_service import preprocess_floor_plan, analyse_floor_plan


def _image_bytes(size=(3000, 1800)):
    image = Image.new("RGB", size, "white")
    out = BytesIO()
    image.save(out, format="PNG")
    return out.getvalue()


def test_fast_preprocessing_limits_image_size():
    processed = preprocess_floor_plan(_image_bytes(), "Fast")
    image = Image.open(BytesIO(processed))
    assert max(image.size) <= 1600
    assert image.mode == "RGB"


def test_pipeline_uses_cache(tmp_path, monkeypatch):
    import services.floorplan_service as service
    monkeypatch.setattr(service, "CACHE_DIR", tmp_path)
    payload = {
        "is_floor_plan": True,
        "north_detected": True,
        "north_confidence": 0.9,
        "rooms": {},
        "issues": [],
    }
    import sys, types
    fake = types.ModuleType("agents.vision_agent")
    fake.inspect_floor_plan = lambda *args, **kwargs: payload
    monkeypatch.setitem(sys.modules, "agents.vision_agent", fake)
    with patch.object(fake, "inspect_floor_plan", return_value=payload) as vision, \
         patch.object(service, "extract_text_local", return_value={"available": False, "text": "", "labels": [], "error": "", "seconds": 0.01}):
        first = analyse_floor_plan(_image_bytes((400, 300)), "Fast", "Top edge")
        second = analyse_floor_plan(_image_bytes((400, 300)), "Fast", "Top edge")
    assert vision.call_count == 1
    assert first["timings"]["cache_hit"] is False
    assert second["timings"]["cache_hit"] is True
