from agents.vastu_agent import vastu_agent


def test_weighted_vastu_engine_returns_professional_fields():
    state = {
        "entrance_direction": "North-East",
        "kitchen_direction": "South-East",
        "master_bedroom_direction": "South-West",
        "toilet_direction": "North-West",
        "pooja_direction": "North-East",
        "living_room_direction": "East",
    }
    result = vastu_agent(state)["vastu_result"]
    assert result["score"] >= 9
    assert result["grade"] in {"A+", "A"}
    assert result["confidence"] in {"Moderate", "High"}
    assert result["evaluated_count"] == 6
    assert result["details"][0]["rationale"]


def test_low_score_creates_priority_issue_and_remedy():
    state = {
        "entrance_direction": "South-West",
        "kitchen_direction": "North-East",
        "toilet_direction": "North-East",
    }
    result = vastu_agent(state)["vastu_result"]
    assert result["critical_issues"]
    assert any(item["severity"] == "Critical" for item in result["critical_issues"])
    assert all(item["non_structural_remedy"] for item in result["critical_issues"])
