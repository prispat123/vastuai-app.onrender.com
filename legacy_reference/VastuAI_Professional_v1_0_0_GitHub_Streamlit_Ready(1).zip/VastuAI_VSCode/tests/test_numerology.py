from datetime import date

from utils.numerology import (
    attitude_number, birth_number, calculate_numerology,
    chaldean_name_number, destiny_number, personal_year_number, property_number,
)


def test_birth_number():
    assert birth_number(date(1990, 12, 28)) == 1

def test_destiny_number():
    assert destiny_number(date(1990, 12, 28)) == 5

def test_attitude_number():
    assert attitude_number(date(1990, 12, 28)) == 4

def test_personal_year_number():
    assert personal_year_number(date(1990, 12, 28), 2026) == 5

def test_chaldean_name_number():
    result = chaldean_name_number("Priscilla")
    assert result["compound_number"] == 25
    assert result["root_number"] == 7

def test_alphanumeric_property_number():
    result = property_number("A-1203")
    assert result["compound_number"] == 7
    assert result["root_number"] == 7
    assert result["breakdown"] == ["A=1", "1=1", "2=2", "0=0", "3=3"]

def test_optional_name_does_not_block_numerology():
    result = calculate_numerology("", date(1990, 12, 28), "A-1203", assessment_year=2026)
    assert result["coverage"] == 80
    assert result["name_root_number"] == 0
    assert len(result["comparisons"]) == 2
    assert 0 <= result["score"] <= 10

def test_full_numerology_profile():
    result = calculate_numerology("Priscilla", date(1990, 12, 28), "A-1203", assessment_year=2026)
    assert result["coverage"] == 100
    assert result["confidence"] == "High"
    assert result["profiles"]["property"]["number"] == 7
    assert len(result["comparisons"]) == 3
