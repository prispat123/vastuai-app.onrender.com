from services.comparison_service import rank_properties
from services.export_service import to_csv_bytes, to_json_bytes
from services.pdf_service import build_comparison_pdf, build_pdf


def sample():
    payload = {"property_name": "Sample Home", "owner_name": "Test", "flat_number": "A-12"}
    result = {
        "final_result": {"score": 8.1, "rating": "Good", "basis": "Combined"},
        "vastu_result": {"score": 8.0, "grade": "A", "coverage": 60, "details": []},
        "numerology_result": {"score": 8.2, "coverage": 100, "property_root_number": 3},
        "recommendation_result": {"decision": "Favourable", "confidence": "High", "actions": []},
        "explanation": "A balanced assessment.",
    }
    return payload, result


def test_exports():
    payload, result = sample()
    assert b"Sample Home" in to_json_bytes(payload, result)
    assert b"overall_score" in to_csv_bytes(payload, result)


def test_pdf_generation():
    payload, result = sample()
    pdf = build_pdf(payload, result)
    assert pdf.startswith(b"%PDF")
    assert len(pdf) > 1000


def test_ranking():
    rows = [{"overall_score": 5, "id": 1}, {"overall_score": 9, "id": 2}]
    ranked = rank_properties(rows)
    assert ranked[0]["id"] == 2
    assert ranked[0]["rank"] == 1


def test_selected_comparison_pdf():
    rows = [
        {"id": 1, "property_label": "Alpha", "flat_number": "A-101", "overall_score": 8.2, "vastu_score": 8.0, "numerology_score": 8.4, "confidence": "High"},
        {"id": 2, "property_label": "Beta", "flat_number": "B-202", "overall_score": 7.5, "vastu_score": 7.2, "numerology_score": 7.8, "confidence": "Medium"},
    ]
    pdf = build_comparison_pdf(rows)
    assert pdf.startswith(b"%PDF")
    assert len(pdf) > 1000
