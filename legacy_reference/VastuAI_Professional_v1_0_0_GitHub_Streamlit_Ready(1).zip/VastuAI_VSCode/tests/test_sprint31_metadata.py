from services import history_service


def test_metadata_columns_and_update(tmp_path, monkeypatch):
    monkeypatch.setattr(history_service, "DB_PATH", tmp_path / "test.db")
    payload = {"property_name": "Test Home", "owner_name": "Owner", "flat_number": "12"}
    result = {"final_result": {"score": 8}, "vastu_result": {"score": 8}, "numerology_result": {"score": 7}, "recommendation_result": {"confidence": "High"}}
    item_id = history_service.save_analysis(payload, result)
    history_service.update_metadata(item_id, "Client ready", "premium, follow-up", "Review entrance remedy.")
    saved = history_service.get_analysis(item_id)
    assert saved["workflow_status"] == "Client ready"
    assert saved["tags"] == "premium, follow-up"
    assert saved["consultant_notes"] == "Review entrance remedy."
