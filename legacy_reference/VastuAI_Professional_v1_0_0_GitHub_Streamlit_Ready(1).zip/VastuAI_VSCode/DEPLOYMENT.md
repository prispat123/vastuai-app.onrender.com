# Deploy VastuAI Professional to Streamlit Community Cloud

## 1. Create the GitHub repository

A private repository is recommended. From the project folder:

```bash
git init
git add .
git commit -m "VastuAI Professional v1.0.0"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/VastuAI-Professional.git
git push -u origin main
```

Confirm that `.env`, `.streamlit/secrets.toml`, database files, logs and generated
exports are not visible in GitHub.

## 2. Deploy

1. Open Streamlit Community Cloud and choose **Create app**.
2. Select the repository and branch `main`.
3. Set the entrypoint to `app.py`.
4. Choose Python 3.12 in Advanced settings.
5. Paste these values into **Secrets**:

```toml
OPENAI_API_KEY = "your_real_key"
OPENAI_MODEL = "gpt-5"
OPENAI_VISION_MODEL = "gpt-4.1-mini"
```

6. Choose the desired `streamlit.app` subdomain and deploy.

## 3. Verify the deployment

- Open **New assessment** and run a manual assessment.
- Upload one sample floor plan and confirm North/room extraction.
- Generate the PDF and ZIP export package.
- Save a record, open it from the portfolio and compare two records.
- Review the Streamlit deployment logs for errors.

## Important storage limitation

The included SQLite database and image cache are suitable for local and single-instance
demonstration use. Streamlit Community Cloud may restart or replace the app filesystem,
so saved portfolio records may disappear. For durable multi-user deployment, replace
SQLite with a managed database such as PostgreSQL and add authentication.
