Set-Location $PSScriptRoot
if (Test-Path ".venv\Scripts\python.exe") {
    & ".venv\Scripts\python.exe" "launch_app.py"
} else {
    python "launch_app.py"
}
