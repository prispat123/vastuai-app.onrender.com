from __future__ import annotations

from datetime import date, datetime
import os
from pathlib import Path

from dotenv import load_dotenv
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

load_dotenv()

# Streamlit Community Cloud exposes configured secrets through st.secrets.
# Copy only known keys into the environment so the service layer remains
# deployable outside Streamlit as well. Local .env values take precedence.
def load_streamlit_secrets() -> None:
    keys = ("OPENAI_API_KEY", "OPENAI_MODEL", "OPENAI_VISION_MODEL", "OPENAI_BASE_URL")
    try:
        for key in keys:
            if not os.getenv(key) and key in st.secrets:
                os.environ[key] = str(st.secrets[key])
    except Exception:
        # A missing secrets.toml is normal during local development.
        pass


load_streamlit_secrets()

from version import __version__
from services.floorplan_service import analyse_floor_plan
from graph import analyze_property
from utils.image_utils import assess_image_quality, image_to_png_bytes, uploaded_file_to_image
from services.export_service import (
    build_export_bundle,
    to_csv_bytes,
    to_direction_balance_csv_bytes,
    to_json_bytes,
    to_room_scores_csv_bytes,
)
from services.history_service import delete_analysis, get_analysis, list_analyses, save_analysis, update_analysis, update_metadata
from services.pdf_service import build_comparison_pdf, build_pdf
from services.comparison_service import rank_properties
from services.logging_service import get_logger

LOGGER = get_logger()

st.set_page_config(
    page_title="VastuAI Professional",
    page_icon="🧭",
    layout="wide",
    initial_sidebar_state="expanded",
)

DIRECTIONS = [
    "Unknown", "North", "North-East", "East", "South-East", "South",
    "South-West", "West", "North-West", "Centre",
]
SUPPORTED_LAYOUT_TYPES = ["png", "jpg", "jpeg", "pdf"]
ROOM_FIELDS = [
    ("entrance_direction", "Main entrance"),
    ("kitchen_direction", "Kitchen"),
    ("master_bedroom_direction", "Master bedroom"),
    ("toilet_direction", "Toilet"),
    ("pooja_direction", "Pooja / meditation room"),
]
EXTRA_ROOM_FIELDS = [
    ("living_room_direction", "Living room"),
    ("balcony_direction", "Balcony / open space"),
    ("staircase_direction", "Staircase"),
    ("children_bedroom_direction", "Children's bedroom"),
    ("guest_bedroom_direction", "Guest bedroom"),
    ("dining_direction", "Dining area"),
    ("brahmasthan_direction", "Brahmasthan / central zone"),
    ("underground_tank_direction", "Underground tank / borewell"),
    ("overhead_tank_direction", "Overhead water tank"),
    ("parking_direction", "Parking"),
]


def apply_theme() -> None:
    st.markdown(
        """
        <style>
        .block-container {max-width:100%;padding:1rem 1.25rem 3rem 1.25rem}
        .hero {padding:1.6rem 1.8rem;border:1px solid rgba(120,120,120,.2);
        border-radius:18px;background:linear-gradient(135deg,rgba(70,120,90,.16),
        rgba(230,170,80,.10));margin-bottom:1rem}
        .hero h1 {margin:0;font-size:2.15rem}.hero p{margin:.5rem 0 0;opacity:.82}
        .step-card{padding:1rem 1.1rem;border:1px solid rgba(120,120,120,.2);
        border-radius:14px;min-height:108px}.step-number{font-size:.78rem;font-weight:700;
        letter-spacing:.08em;text-transform:uppercase;opacity:.65}.step-title{font-size:1.03rem;
        font-weight:700;margin-top:.25rem}.soft-note{padding:.9rem 1rem;border-left:4px solid #b58b40;
        background:rgba(181,139,64,.10);border-radius:8px}div[data-testid="stMetric"]{
        border:1px solid rgba(120,120,120,.18);border-radius:14px;padding:.8rem 1rem}
        </style>
        """,
        unsafe_allow_html=True,
    )


def initialise_session_state() -> None:
    defaults = {
        "analysis_result": None,
        "analysis_complete": False,
        "input_mode": "Enter details manually",
        "layout_extraction": None,
        "layout_image_bytes": None,
        "last_payload": None,
        "last_saved_analysis_id": None,
        "editing_analysis_id": None,
        "edit_payload": None,
        "active_page": "New assessment",
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def _clear_form_widgets() -> None:
    prefixes = ("manual_", "review_", "layout_")
    explicit = {"uploaded_floor_plan"}
    for key in list(st.session_state.keys()):
        if key.startswith(prefixes) or key in explicit:
            del st.session_state[key]


def reset_analysis(clear_forms: bool = False) -> None:
    st.session_state.analysis_result = None
    st.session_state.analysis_complete = False
    st.session_state.layout_extraction = None
    st.session_state.layout_image_bytes = None
    st.session_state.last_saved_analysis_id = None
    st.session_state.editing_analysis_id = None
    st.session_state.edit_payload = None
    if clear_forms:
        _clear_form_widgets()


def start_new_record() -> None:
    """Leave edit mode and initialise a completely blank assessment."""
    reset_analysis(clear_forms=True)
    # Clear navigation/widget values explicitly. This is important when the user
    # clicks Add another record while a saved record is open in Modify mode.
    st.session_state.input_mode = "Enter details manually"
    st.session_state.active_page = "New assessment"
    st.session_state.main_menu = "New assessment"
    st.session_state.assessment_notice = "A new blank assessment is ready."


def prepare_record_for_edit(analysis_id: int, payload: dict) -> None:
    _clear_form_widgets()
    st.session_state.editing_analysis_id = int(analysis_id)
    st.session_state.edit_payload = dict(payload)
    st.session_state.input_mode = "Enter details manually"
    st.session_state.analysis_result = None
    st.session_state.analysis_complete = False
    st.session_state.layout_extraction = None
    st.session_state.layout_image_bytes = None
    st.session_state.active_page = "New assessment"


def parse_optional_dob(text: str) -> str:
    text = text.strip()
    if not text:
        return ""
    for fmt in ("%d/%m/%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(text, fmt).date().isoformat()
        except ValueError:
            pass
    return text


def render_workflow_steps() -> None:
    cols = st.columns(4)
    steps = [
        ("Step 1", "Provide details", "Manual entry or layout upload"),
        ("Step 2", "Validate layout", "North arrow and image quality"),
        ("Step 3", "Review extraction", "Confirm or correct AI results"),
        ("Step 4", "Run assessment", "Vastu, numerology and report"),
    ]
    for col, (number, title, text) in zip(cols, steps):
        with col:
            st.markdown(
                f'<div class="step-card"><div class="step-number">{number}</div>'
                f'<div class="step-title">{title}</div><div>{text}</div></div>',
                unsafe_allow_html=True,
            )


def render_vastu_details(details: list[dict]) -> None:
    if not details:
        st.info("Vastu was not assessed because the minimum Vastu information was not available.")
        return

    for item in details:
        score = float(item.get("score", 0))
        icon = "✅" if score >= 8 else "⚠️" if score >= 5 else "❗"
        with st.expander(
            f"{icon} {item.get('area', 'Area')} — {item.get('direction', 'Unknown')} "
            f"({score:g}/10, {item.get('status', 'Not rated')})"
        ):
            c1, c2, c3 = st.columns(3)
            c1.metric("Score", f"{score:g}/10")
            c2.metric("Issue severity", item.get("severity", "N/A"))
            c3.metric("Rule weight", item.get("weight", 1.0))
            st.write(item.get("rationale", ""))
            preferred = item.get("preferred", [])
            if preferred:
                st.write("**Traditionally preferred:** " + ", ".join(preferred))
            if score < 7:
                st.markdown("**Practical non-structural measure**")
                st.write(item.get("non_structural_remedy", "No remedy configured."))
                st.markdown("**Structural option — professional review required**")
                st.write(item.get("structural_remedy", "No structural option configured."))


def render_direction_wheel(details: list[dict]) -> None:
    direction_order = ["North", "North-East", "East", "South-East", "South", "South-West", "West", "North-West"]
    aliases = {d.lower().replace(" ", "-"): d for d in direction_order}
    values = {d: [] for d in direction_order}
    for item in details:
        raw = str(item.get("direction", "")).strip()
        normal = raw.title().replace("Northeast", "North-East").replace("Southeast", "South-East").replace("Southwest", "South-West").replace("Northwest", "North-West")
        if normal in values:
            values[normal].append(float(item.get("score", 0) or 0))
    if not any(values.values()):
        st.info("The direction wheel will appear when directional room data is available.")
        return
    import numpy as np
    scores = [sum(values[d]) / len(values[d]) if values[d] else 0 for d in direction_order]
    angles = np.linspace(0, 2 * np.pi, len(direction_order), endpoint=False).tolist()
    angles += angles[:1]; plot_scores = scores + scores[:1]
    fig = plt.figure(figsize=(6.2, 6.2))
    ax = fig.add_subplot(111, polar=True)
    ax.set_theta_zero_location("N"); ax.set_theta_direction(-1)
    ax.plot(angles, plot_scores, marker="o", linewidth=2, label="Average room score")
    ax.fill(angles, plot_scores, alpha=.16)
    ax.set_xticks(angles[:-1]); ax.set_xticklabels(direction_order)
    ax.set_ylim(0, 10); ax.set_yticks([2, 4, 6, 8, 10]); ax.set_title("Directional balance wheel", pad=22)
    ax.legend(loc="lower center", bbox_to_anchor=(.5, -0.18))
    fig.tight_layout(); st.pyplot(fig, clear_figure=True)


def render_results(result: dict, payload: dict) -> None:
    final = result.get("final_result", {})
    vastu = result.get("vastu_result", {})
    numerology = result.get("numerology_result", {})
    recommendation = result.get("recommendation_result", {})

    st.divider()
    property_label = payload.get("property_name") or payload.get("flat_number") or "Property assessment"
    rating = final.get("rating", final.get("basis", "Assessment complete"))
    st.markdown(f'<div class="result-banner"><h2>{property_label}</h2><span class="status-pill">{rating}</span><span class="status-pill">Score {final.get("score", 0)}/10</span></div>', unsafe_allow_html=True)
    cols = st.columns(4)
    cols[0].metric("Overall score", f"{final.get('score', 0)}/10")
    cols[1].metric("Vastu score", f"{vastu.get('score', 'Not assessed')}")
    cols[2].metric("Numerology", f"{numerology.get('score', 'Not assessed')}")
    cols[3].metric("Basis", final.get("basis", final.get("rating", "N/A")))
    st.progress(min(max(float(final.get("score", 0)) / 10, 0.0), 1.0))

    dashboard_tab, overview_tab, vastu_tab, numerology_tab, recommendation_tab, consultant_tab, report_tab = st.tabs(
        ["Executive summary", "Overview", "Vastu", "Numerology", "Recommendations", "Consultant workspace", "Reports & export"]
    )
    with dashboard_tab:
        st.markdown("### Assessment dashboard")
        dcols = st.columns(4)
        dcols[0].metric("Overall", f"{final.get('score', 0)}/10")
        dcols[1].metric("Vastu", f"{vastu.get('score', 'N/A')}")
        dcols[2].metric("Numerology", f"{numerology.get('score', 'N/A')}")
        dcols[3].metric("Confidence", recommendation.get("confidence", "N/A"))
        chart_left, chart_right = st.columns(2)
        with chart_left:
            labels, scores = [], []
            for item in vastu.get("details", []):
                labels.append(str(item.get("area", "Area")))
                scores.append(float(item.get("score", 0) or 0))
            if scores:
                fig, ax = plt.subplots(figsize=(7, max(3, len(scores) * .35)))
                ax.barh(labels, scores)
                ax.set_xlim(0, 10)
                ax.set_xlabel("Score out of 10")
                ax.set_title("Room-wise Vastu scores")
                fig.tight_layout()
                st.pyplot(fig, clear_figure=True)
            else:
                st.info("Room-wise chart will appear when Vastu details are available.")
        with chart_right:
            severity_counts = {}
            for item in vastu.get("details", []):
                severity = str(item.get("severity", "None"))
                severity_counts[severity] = severity_counts.get(severity, 0) + 1
            if severity_counts:
                fig, ax = plt.subplots(figsize=(5, 4))
                ax.pie(severity_counts.values(), labels=severity_counts.keys(), autopct="%1.0f%%")
                ax.set_title("Issue severity distribution")
                fig.tight_layout()
                st.pyplot(fig, clear_figure=True)
            else:
                st.info("Severity chart will appear after Vastu assessment.")
        st.markdown("### Directional balance")
        render_direction_wheel(vastu.get("details", []))
    with overview_tab:
        st.markdown("### AI explanation")
        st.write(result.get("explanation", "No explanation available."))
        if vastu.get("coverage") is not None:
            st.write(f"**Vastu coverage:** {vastu['coverage']}% ({vastu.get('evaluated_count', 0)} core factors evaluated)")

    with vastu_tab:
        st.markdown("### Professional Vastu assessment")
        summary_cols = st.columns(4)
        summary_cols[0].metric("Vastu grade", vastu.get("grade", "N/A"))
        summary_cols[1].metric("Coverage", f"{vastu.get('coverage', 0)}%")
        summary_cols[2].metric("Confidence", vastu.get("confidence", "N/A"))
        summary_cols[3].metric("Factors evaluated", vastu.get("evaluated_count", 0))

        critical = vastu.get("critical_issues", [])
        if critical:
            st.markdown("#### Priority issues")
            for item in critical:
                st.error(
                    f"{item.get('severity', 'High')} — {item.get('area')} in "
                    f"{item.get('direction')} ({item.get('score', 0):g}/10)"
                )

        st.markdown("#### Room-by-room rules, severity and remedies")
        render_vastu_details(vastu.get("details", []))

        if vastu.get("strengths"):
            st.markdown("#### Strengths")
            for item in vastu.get("strengths", []):
                st.write(f"✅ {item}")
        if vastu.get("cautions"):
            st.markdown("#### Points to review")
            for item in vastu.get("cautions", []):
                st.write(f"⚠️ {item}")

    with numerology_tab:
        if not numerology:
            st.info("Numerology was not assessed. Provide a property number and valid date of birth.")
        else:
            st.markdown("### Advanced Chaldean numerology")
            ncols = st.columns(4)
            ncols[0].metric("Numerology score", f"{numerology.get('score', 0)}/10")
            ncols[1].metric("Coverage", f"{numerology.get('coverage', 0)}%")
            ncols[2].metric("Confidence", numerology.get('confidence', 'N/A'))
            ncols[3].metric("Assessment year", numerology.get('assessment_year', 'N/A'))

            st.markdown("#### Core numbers")
            core = st.columns(5)
            core[0].metric("Birth", numerology.get('birth_number', 'N/A'))
            core[1].metric("Destiny", numerology.get('destiny_number', 'N/A'))
            core[2].metric("Attitude", numerology.get('attitude_number', 'N/A'))
            core[3].metric("Name root", numerology.get('name_root_number') or 'Not provided')
            core[4].metric("Personal year", numerology.get('personal_year_number', 'N/A'))

            st.markdown("#### Property number calculation")
            st.write(f"**Cleaned identifier:** {numerology.get('property_cleaned_number', '')}")
            st.write("**Breakdown:** " + " + ".join(numerology.get('property_breakdown', [])))
            st.write(f"**Compound → root:** {numerology.get('property_compound_number')} → {numerology.get('property_root_number')}")
            st.caption(numerology.get('property_compound_note', ''))

            st.markdown("#### Compatibility breakdown")
            for item in numerology.get('comparisons', []):
                label = item.get('reference', 'Reference')
                with st.expander(f"{label} {item.get('number')} — {item.get('status')} ({item.get('score_5')}/5)"):
                    st.write(item.get('explanation', ''))
                    st.write(f"Weight in numerology score: {float(item.get('weight', 0)):.0%}")

            st.markdown("#### Number profiles")
            profiles = numerology.get('profiles', {})
            for key, label in (("property", "Property root"), ("birth", "Birth number"), ("destiny", "Destiny number"), ("name", "Name number"), ("personal_year", "Personal year")):
                profile = profiles.get(key) or {}
                if not profile:
                    continue
                with st.expander(f"{label}: {profile.get('number')} — {profile.get('planet', '')}"):
                    st.write(profile.get('summary', ''))
                    if profile.get('keywords'):
                        st.write("**Traditional themes:** " + ", ".join(profile['keywords']))
                    if profile.get('supportive_directions'):
                        st.write("**Traditionally supportive directions:** " + ", ".join(profile['supportive_directions']))
                    if profile.get('supportive_colours'):
                        st.write("**Traditionally supportive colours:** " + ", ".join(profile['supportive_colours']))

            if numerology.get('strengths'):
                st.markdown("#### Strengths")
                for item in numerology['strengths']:
                    st.write(f"✅ {item}")
            if numerology.get('cautions'):
                st.markdown("#### Points to review")
                for item in numerology['cautions']:
                    st.write(f"⚠️ {item}")
            st.info(numerology.get('disclaimer', 'Numerology is belief-based guidance.'))

    with recommendation_tab:
        st.markdown("### Combined decision guidance")
        rcols = st.columns(4)
        rcols[0].metric("Decision", recommendation.get("decision", "N/A"))
        rcols[1].metric("Outlook", recommendation.get("sentiment", "N/A"))
        rcols[2].metric("Confidence", recommendation.get("confidence", "N/A"))
        rcols[3].metric("High-priority issues", recommendation.get("critical_issue_count", 0))

        for note in recommendation.get("synergy_notes", []):
            st.info(note)

        if recommendation.get("strengths"):
            st.markdown("#### Combined strengths")
            for item in recommendation["strengths"]:
                st.write(f"✅ {item}")

        if recommendation.get("actions"):
            st.markdown("#### Prioritised action plan")
            for index, item in enumerate(recommendation["actions"], start=1):
                with st.expander(f"{index}. {item.get('priority', 'Medium')} — {item.get('area', 'Property feature')}", expanded=index == 1):
                    st.write(f"**Finding:** {item.get('finding', '')}")
                    st.write(f"**Why it matters:** {item.get('why_it_matters', '')}")
                    st.write(f"**Practical action:** {item.get('practical_action', '')}")
                    st.warning(f"Structural option: {item.get('structural_option', '')}")

        st.markdown("#### Due-diligence next steps")
        for item in recommendation.get("next_steps", []):
            st.write(f"• {item}")
        st.caption(recommendation.get("disclaimer", ""))

    with consultant_tab:
        st.markdown("### Consultant workspace")
        analysis_id = st.session_state.get("last_saved_analysis_id")
        if not analysis_id:
            st.info("Save the assessment before adding workflow status, tags and consultant notes.")
        else:
            saved = get_analysis(int(analysis_id)) or {}
            statuses = ["Draft", "Needs review", "Client ready", "Client approved", "Archived"]
            current_status = saved.get("workflow_status") or "Draft"
            status_index = statuses.index(current_status) if current_status in statuses else 0
            c1, c2 = st.columns([1, 2])
            workflow_status = c1.selectbox("Workflow status", statuses, index=status_index, key=f"status_{analysis_id}")
            tags = c2.text_input("Tags", value=saved.get("tags") or "", placeholder="Example: premium, north-facing, follow-up", key=f"tags_{analysis_id}")
            consultant_notes = st.text_area("Consultant observations", value=saved.get("consultant_notes") or "", height=180,
                placeholder="Record client-specific observations, follow-up questions and professional judgement.", key=f"notes_{analysis_id}")
            if st.button("Save consultant workspace", type="primary", use_container_width=True):
                update_metadata(int(analysis_id), workflow_status, tags, consultant_notes)
                st.success("Status, tags and consultant notes saved.")
            st.caption("These notes are stored with the portfolio record and are not used to recalculate the Vastu score.")

    with report_tab:
        report_text = f"""VastuAI Property Compatibility Report

Owner: {payload.get('owner_name') or 'Not provided'}
Date of birth: {payload.get('dob') or 'Not provided'}
Apartment / property number: {payload.get('flat_number') or 'Not provided'}

Overall score: {final.get('score', 0)}/10
Rating: {final.get('rating', 'N/A')}
Assessment basis: {final.get('basis', 'N/A')}
Vastu score: {vastu.get('score', 'Not assessed')}
Vastu grade: {vastu.get('grade', 'N/A')}
Vastu coverage: {vastu.get('coverage', 0)}%
Vastu confidence: {vastu.get('confidence', 'N/A')}
Numerology score: {numerology.get('score', 'Not assessed')}
Numerology coverage: {numerology.get('coverage', 'Not assessed')}%
Birth / destiny / attitude: {numerology.get('birth_number', 'N/A')} / {numerology.get('destiny_number', 'N/A')} / {numerology.get('attitude_number', 'N/A')}
Name compound / root: {numerology.get('name_compound_number', 'N/A')} / {numerology.get('name_root_number', 'N/A')}
Property compound / root: {numerology.get('property_compound_number', 'N/A')} / {numerology.get('property_root_number', 'N/A')}
Personal year: {numerology.get('personal_year_number', 'N/A')}

Decision guidance: {recommendation.get('decision', 'N/A')}
Recommendation confidence: {recommendation.get('confidence', 'N/A')}
High-priority issues: {recommendation.get('critical_issue_count', 0)}

Explanation:
{result.get('explanation', '')}

Disclaimer:
This is belief-based guidance, not structural, legal, financial, scientific or investment advice.
"""
        st.markdown("### Professional reports and export package")
        st.caption("Sprint 3.2 reports include the directional balance wheel, room-wise score chart, direction summary table and detailed assessment findings.")
        property_slug = str(payload.get("property_name") or payload.get("flat_number") or "property").strip().replace(" ", "_")
        try:
            pdf_bytes = build_pdf(payload, result)
            bundle_bytes = build_export_bundle(payload, result, build_pdf, report_text)
            primary_left, primary_right = st.columns(2)
            primary_left.download_button(
                "Download visual professional PDF", pdf_bytes,
                f"VastuAI_{property_slug}.pdf", "application/pdf",
                type="primary", use_container_width=True,
            )
            primary_right.download_button(
                "Download complete export package", bundle_bytes,
                f"VastuAI_{property_slug}_Export_Package.zip", "application/zip",
                use_container_width=True,
            )
        except Exception as exc:
            st.error(f"Report generation failed: {exc}")
        st.markdown("#### Data exports")
        c1, c2, c3 = st.columns(3)
        c1.download_button("Assessment summary CSV", to_csv_bytes(payload, result), f"VastuAI_{property_slug}_Summary.csv", "text/csv", use_container_width=True)
        c2.download_button("Room scores CSV", to_room_scores_csv_bytes(result), f"VastuAI_{property_slug}_Room_Scores.csv", "text/csv", use_container_width=True)
        c3.download_button("Direction balance CSV", to_direction_balance_csv_bytes(result), f"VastuAI_{property_slug}_Direction_Balance.csv", "text/csv", use_container_width=True)
        d1, d2, d3 = st.columns(3)
        d1.download_button("Download enriched JSON", to_json_bytes(payload, result), f"VastuAI_{property_slug}.json", "application/json", use_container_width=True)
        d2.download_button("Download text report", report_text, f"VastuAI_{property_slug}.txt", "text/plain", use_container_width=True)
        d3.info("The ZIP package contains the PDF, both chart images, all CSV exports, JSON and text report.")


def direction_select(label: str, key: str, default: str = "Unknown") -> str:
    index = DIRECTIONS.index(default) if default in DIRECTIONS else 0
    return st.selectbox(label, DIRECTIONS, index=index, key=key)


def run_assessment(payload: dict) -> None:
    """Run the assessment, persist it, and move the user to Results.

    Any graph/runtime failure is shown in the UI instead of leaving the button
    looking unresponsive. Validation errors remain on the current form.
    """
    try:
        with st.spinner("Running the LangGraph assessment..."):
            result = analyze_property(payload)
    except Exception as exc:
        LOGGER.exception("Assessment failed")
        st.session_state.analysis_complete = False
        st.session_state.analysis_result = None
        st.error(f"Assessment could not be completed: {exc}")
        return

    errors = result.get("validation_errors", [])
    if errors:
        st.error("Please correct the following:")
        for error in errors:
            st.write(f"- {error}")
        return

    st.session_state.analysis_result = result
    st.session_state.analysis_complete = True
    st.session_state.last_payload = payload

    save_warning = None
    try:
        editing_id = st.session_state.get("editing_analysis_id")
        if editing_id:
            update_analysis(int(editing_id), payload, result)
            analysis_id = int(editing_id)
            st.session_state.editing_analysis_id = None
            st.session_state.edit_payload = None
            LOGGER.info(
                "Analysis %s updated for %s",
                analysis_id,
                payload.get("property_name") or payload.get("flat_number") or "Unnamed",
            )
        else:
            analysis_id = save_analysis(payload, result)
            LOGGER.info(
                "Analysis %s saved for %s",
                analysis_id,
                payload.get("property_name") or payload.get("flat_number") or "Unnamed",
            )
        st.session_state.last_saved_analysis_id = analysis_id
    except Exception as exc:
        LOGGER.exception("Could not save analysis")
        save_warning = f"Assessment completed, but history could not be saved: {exc}"

    st.session_state.assessment_notice = save_warning or "Assessment completed successfully."
    st.session_state.active_page = "Results"
    st.rerun()


def render_manual_form() -> None:
    edit_payload = st.session_state.get("edit_payload") or {}
    editing_id = st.session_state.get("editing_analysis_id")
    st.markdown("### Modify saved property" if editing_id else "### Manual property entry")
    if editing_id:
        st.info(f"Editing saved record P{editing_id}. Submitting will update the existing record rather than create a duplicate.")
    st.caption("Minimum required: entrance plus two other Vastu directions, OR property number plus date of birth. All extended Vastu fields are optional.")
    with st.form("manual_property_form"):
        left, right = st.columns(2, gap="large")
        with left:
            property_name = st.text_input("Property name / label (optional)", value=str(edit_payload.get("property_name", "")), key="manual_property_name")
            owner_name = st.text_input("Owner's full name (optional)", value=str(edit_payload.get("owner_name", "")), key="manual_owner_name")
            dob_text = st.text_input("Date of birth (optional, DD/MM/YYYY)", value=str(edit_payload.get("dob", "")), placeholder="26/07/1990", key="manual_dob")
            flat_number = st.text_input("Apartment / flat / house / villa number (optional)", value=str(edit_payload.get("flat_number", "")), key="manual_flat_number")
            assessment_year = st.number_input("Numerology assessment year (optional)", min_value=1900, max_value=2100, value=int(edit_payload.get("assessment_year") or date.today().year), step=1, key="manual_assessment_year")
        values = {}
        with right:
            for field, label in ROOM_FIELDS:
                values[field] = direction_select(label, f"manual_{field}", str(edit_payload.get(field, "Unknown")))
        with st.expander("Extended Vastu details (optional)", expanded=False):
            cols = st.columns(2)
            for index, (field, label) in enumerate(EXTRA_ROOM_FIELDS):
                with cols[index % 2]:
                    values[field] = direction_select(label, f"manual_{field}", str(edit_payload.get(field, "Unknown")))
        submitted = st.form_submit_button("Update assessment" if editing_id else "Analyse property", type="primary", use_container_width=True)

    if submitted:
        payload = {
            "property_name": property_name.strip(),
            "owner_name": owner_name.strip(),
            "dob": parse_optional_dob(dob_text),
            "flat_number": flat_number.strip(),
            "assessment_year": int(assessment_year),
            **values,
        }
        run_assessment(payload)


def extraction_default(extraction: dict, field: str) -> str:
    return extraction.get("rooms", {}).get(field, {}).get("value", "Unknown")


def render_extraction_review(extraction: dict) -> None:
    st.markdown("### Review detected rooms and directions")
    st.warning("AI and OCR results are advisory. Change any room direction before assessment.")

    room_labels = dict(ROOM_FIELDS + EXTRA_ROOM_FIELDS)
    extracted_rooms = extraction.get("rooms", {})

    # Individual controls are deliberately used instead of a wide data editor.
    # This keeps the direction selector visible on smaller displays and avoids
    # dependence on a horizontal scrollbar.
    reviewed_rows = []
    st.caption("Every detected feature has its own editable direction dropdown.")
    for index, (field, label) in enumerate(room_labels.items()):
        item = extracted_rooms.get(field, {})
        detected_direction = str(item.get("value", "Unknown"))
        if detected_direction not in DIRECTIONS:
            detected_direction = "Unknown"
        confidence = float(item.get("confidence", 0.0) or 0.0)

        with st.container(border=True):
            c1, c2, c3 = st.columns([1.2, 2.4, 1.2], gap="medium")
            include = c1.checkbox(
                "Include",
                value=detected_direction != "Unknown",
                key=f"review_include_{field}",
            )
            direction = c2.selectbox(
                f"{label} — change direction",
                DIRECTIONS,
                index=DIRECTIONS.index(detected_direction),
                key=f"review_direction_{field}",
                help=f"AI detected: {detected_direction}. Select the correct direction here.",
            )
            c3.metric("AI confidence", f"{confidence:.0%}")
            reviewed_rows.append({
                "field": field,
                "label": label,
                "include": include,
                "direction": direction,
                "confidence": confidence,
            })

    ocr = extraction.get("ocr", {})
    with st.expander("OCR text and performance details", expanded=False):
        if ocr.get("available"):
            st.caption("Locally extracted labels")
            st.code(ocr.get("text") or "No readable labels found.")
        else:
            st.info("Local OCR was skipped or unavailable. Vision analysis still completed. Install Tesseract OCR for local text extraction.")
            if ocr.get("error"):
                st.caption(ocr["error"])
        st.json(extraction.get("timings", {}))

    with st.form("layout_review_form"):
        left, right = st.columns(2, gap="large")
        with left:
            property_name = st.text_input("Property name / label (optional)", key="review_property_name")
            owner_name = st.text_input("Owner's full name (optional)", key="review_owner_name")
            dob_text = st.text_input("Date of birth (optional, DD/MM/YYYY)", placeholder="26/07/1990", key="review_dob")
        with right:
            flat_number = st.text_input("Apartment / flat / house / villa number (optional)", key="review_flat_number")
            assessment_year = st.number_input("Numerology assessment year", min_value=1900, max_value=2100, value=date.today().year, step=1, key="review_assessment_year")
            confirmed = st.checkbox("I reviewed the detected rooms and directions.", key="review_confirmed")
        submitted = st.form_submit_button("Apply directions and analyse property", type="primary", use_container_width=True)

    if submitted:
        if not confirmed:
            st.error("Please confirm that you reviewed the detected layout.")
            return
        values = {field: "Unknown" for field in room_labels}
        for row in reviewed_rows:
            if row["include"]:
                values[row["field"]] = row["direction"]
        payload = {
            "property_name": property_name.strip(),
            "owner_name": owner_name.strip(),
            "dob": parse_optional_dob(dob_text),
            "flat_number": flat_number.strip(),
            "assessment_year": int(assessment_year),
            "floorplan_analysis": {
                "mode": extraction.get("analysis_mode"),
                "north_orientation": extraction.get("north_orientation"),
                "timings": extraction.get("timings", {}),
                "ocr_labels": extraction.get("ocr", {}).get("labels", []),
            },
            **values,
        }
        run_assessment(payload)


def render_layout_upload() -> None:
    st.markdown("### Upload and analyse a floor plan")
    st.caption("Fast Mode is recommended. Results are cached, so the same plan opens almost instantly after its first analysis.")

    controls = st.columns([1, 1, 2])
    analysis_mode = controls[0].selectbox("Analysis mode", ["Fast", "Detailed"], index=0, key="layout_analysis_mode")
    north_orientation = controls[1].selectbox(
        "North orientation",
        ["Auto-detect", "Top edge", "Right edge", "Bottom edge", "Left edge"],
        key="layout_north_orientation",
    )
    controls[2].info("Fast: smaller image and low-detail vision. Detailed: higher resolution and high-detail vision.")

    uploaded_file = st.file_uploader("Choose a floor-plan file", type=SUPPORTED_LAYOUT_TYPES, key="uploaded_floor_plan")
    if uploaded_file is None:
        st.info("Upload a floor plan to begin analysis.")
        return

    file_bytes = uploaded_file.getvalue()
    try:
        image = uploaded_file_to_image(file_bytes, uploaded_file.name)
    except Exception as exc:
        st.error(f"Could not open this layout: {exc}")
        return

    png_bytes = image_to_png_bytes(image)
    quality = assess_image_quality(image)
    st.image(image, caption="Uploaded floor plan / first PDF page", use_container_width=True)

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Format", Path(uploaded_file.name).suffix.replace(".", "").upper())
    c2.metric("Dimensions", f"{quality.width} × {quality.height}")
    c3.metric("Local quality", f"{quality.quality_score}/100")
    c4.metric("Mode", analysis_mode)

    for issue in quality.issues:
        st.warning(issue)
    if not os.getenv("OPENAI_API_KEY"):
        st.error("Configure OPENAI_API_KEY in .env locally or in Streamlit Cloud Secrets before using automated layout analysis.")
        return

    action_cols = st.columns([3, 1])
    analyse_clicked = action_cols[0].button("Analyse floor plan", type="primary", use_container_width=True)
    refresh_clicked = action_cols[1].button("Force refresh", use_container_width=True)
    if analyse_clicked or refresh_clicked:
        with st.spinner("Preprocessing and running OCR + vision analysis..."):
            try:
                extraction = analyse_floor_plan(
                    png_bytes,
                    mode=analysis_mode,
                    north_orientation=north_orientation,
                    force_refresh=refresh_clicked,
                )
                extraction["local_quality"] = quality.__dict__
                st.session_state.layout_extraction = extraction
                st.session_state.layout_image_bytes = png_bytes
            except Exception as exc:
                LOGGER.exception("Floor-plan analysis failed")
                st.error(f"Floor-plan analysis failed: {exc}")
                return

    extraction = st.session_state.layout_extraction
    if not extraction:
        return

    st.divider()
    timings = extraction.get("timings", {})
    a, b, c, d = st.columns(4)
    a.metric("Floor plan", "Detected" if extraction.get("is_floor_plan") else "Unconfirmed")
    b.metric("North", "Detected" if extraction.get("north_detected") else north_orientation)
    c.metric("Confidence", f"{extraction.get('north_confidence', 0):.0%}")
    d.metric("Total time", f"{timings.get('total_seconds', 0):.1f}s", "Cache hit" if timings.get("cache_hit") else None)

    for issue in extraction.get("issues", []):
        st.warning(issue)
    if not extraction.get("is_floor_plan"):
        st.error("The uploaded image could not be confirmed as a floor plan.")
        return
    if north_orientation == "Auto-detect" and (not extraction.get("north_detected") or extraction.get("north_confidence", 0) < 0.65):
        st.error("North could not be detected reliably. Select the correct page edge as North or upload a clearer plan.")
        return
    if quality.quality_score < 35:
        st.error("Image quality is too low for dependable extraction.")
        return

    if timings.get("cache_hit"):
        st.success("Loaded the previous analysis from cache.")
    else:
        st.success("Analysis completed. Review and correct the detections below.")
    render_extraction_review(extraction)


def _portfolio_frame(rows: list[dict]) -> pd.DataFrame:
    ranked = rank_properties(rows)
    return pd.DataFrame([{
        "Rank": row["rank"], "Key": f"P{row['id']}", "ID": row["id"],
        "Property": row["property_label"],
        "Apartment number": row.get("flat_number") or "Not provided",
        "Display name": (f"{row['property_label']} ({row.get('flat_number')})"
                         if row.get("flat_number") and str(row.get("flat_number")) not in str(row["property_label"])
                         else str(row["property_label"])),
        "Owner": row.get("owner_name") or "", "Overall": row.get("overall_score"),
        "Vastu": row.get("vastu_score"), "Numerology": row.get("numerology_score"),
        "Confidence": row.get("confidence"),
        "Status": row.get("workflow_status") or "Draft",
        "Tags": row.get("tags") or "",
        "Created": str(row.get("created_at", ""))[:19].replace("T", " "),
    } for row in ranked])


def render_portfolio() -> None:
    st.subheader("Saved portfolio")
    rows = list_analyses(500)
    if not rows:
        st.info("No saved assessments yet. Create an assessment first.")
        return
    frame = _portfolio_frame(rows)
    c1, c2, c3, c4 = st.columns([2, 1, 1, 1])
    search = c1.text_input("Search", placeholder="Property, owner, status or tags")
    sort_by = c2.selectbox("Sort by", ["Newest", "Highest score", "Property name"])
    min_score = c3.number_input("Minimum score", min_value=0.0, max_value=10.0, value=0.0, step=0.5)
    status_filter = c4.selectbox("Status", ["All"] + sorted(frame["Status"].astype(str).unique().tolist()))
    view = frame.copy()
    if search.strip():
        q = search.strip().lower()
        view = view[view.apply(lambda r: q in " ".join(map(str, r.values)).lower(), axis=1)]
    view = view[pd.to_numeric(view["Overall"], errors="coerce").fillna(0) >= min_score]
    if status_filter != "All": view = view[view["Status"] == status_filter]
    if sort_by == "Highest score": view = view.sort_values("Overall", ascending=False)
    elif sort_by == "Property name": view = view.sort_values("Property")
    else: view = view.sort_values("ID", ascending=False)
    st.dataframe(view[["Key","Property","Apartment number","Owner","Overall","Vastu","Numerology","Status","Tags","Created"]], use_container_width=True, hide_index=True)
    if view.empty:
        st.warning("No records match the current filters.")
        return
    selected_id = st.selectbox("Selected record", view["ID"].tolist(),
        format_func=lambda value: f"P{value} — {frame.loc[frame['ID']==value,'Display name'].iloc[0]}")
    a,b,c,d = st.columns(4)
    if a.button("📂 Load", use_container_width=True):
        saved=get_analysis(int(selected_id))
        if saved:
            st.session_state.analysis_result=saved["result"]; st.session_state.last_payload=saved["payload"]
            st.session_state.last_saved_analysis_id=int(selected_id); st.session_state.analysis_complete=True
            st.session_state.editing_analysis_id=None; st.session_state.edit_payload=None
            st.session_state.active_page="Results"; st.rerun()
    if b.button("✏️ Edit", use_container_width=True):
        saved=get_analysis(int(selected_id))
        if saved: prepare_record_for_edit(int(selected_id), saved["payload"]); st.rerun()
    if c.button("📄 Duplicate", use_container_width=True):
        saved=get_analysis(int(selected_id))
        if saved:
            new_payload=dict(saved["payload"]); new_payload["property_name"] = f"{new_payload.get('property_name') or new_payload.get('flat_number') or 'Property'} copy"
            new_id=save_analysis(new_payload, saved["result"])
            st.success(f"Duplicated as P{new_id}."); st.rerun()
    if d.button("🗑️ Delete", use_container_width=True):
        st.session_state.pending_delete_id=int(selected_id)
    if st.session_state.get("pending_delete_id") == int(selected_id):
        st.warning(f"Delete P{selected_id}? This cannot be undone.")
        y,n=st.columns(2)
        if y.button("Yes, delete", type="primary", use_container_width=True):
            delete_analysis(int(selected_id)); st.session_state.pending_delete_id=None; st.rerun()
        if n.button("Cancel", use_container_width=True): st.session_state.pending_delete_id=None; st.rerun()


def render_comparison() -> None:
    st.subheader("Compare properties")
    rows=list_analyses(500)
    if len(rows)<2:
        st.info("Save at least two assessments to create a comparison.")
        return
    frame=_portfolio_frame(rows)
    selected_ids=st.multiselect("Select two or more records", frame["ID"].tolist(),
        format_func=lambda value: f"P{value} — {frame.loc[frame['ID']==value,'Display name'].iloc[0]}")
    if len(selected_ids)<2:
        st.info("Choose at least two records.")
        return
    selected=frame[frame["ID"].isin(selected_ids)].copy().sort_values("Overall",ascending=False)
    selected.insert(0,"Selected rank",range(1,len(selected)+1))
    st.dataframe(selected[["Selected rank","Key","Property","Apartment number","Overall","Vastu","Numerology","Confidence"]],use_container_width=True,hide_index=True)
    fig,ax=plt.subplots(figsize=(9,max(3.5,len(selected)*.6)))
    plot=selected.sort_values("Overall")
    ax.barh(plot["Key"],pd.to_numeric(plot["Overall"],errors="coerce").fillna(0)); ax.set_xlim(0,10)
    ax.set_xlabel("Overall score"); ax.set_title("Selected property comparison"); fig.tight_layout(); st.pyplot(fig,clear_figure=True)
    st.dataframe(selected[["Key","Display name"]].rename(columns={"Display name":"Property legend"}),use_container_width=True,hide_index=True)
    chosen={int(x) for x in selected_ids}; selected_rows=[r for r in rows if int(r["id"]) in chosen]
    try:
        pdf=build_comparison_pdf(selected_rows)
        st.download_button("Download comparison PDF",pdf,"VastuAI_Selected_Comparison.pdf","application/pdf",type="primary",use_container_width=True)
    except Exception as exc: st.error(f"Comparison PDF generation failed: {exc}")


def render_dashboard() -> None:
    st.subheader("Portfolio dashboard")
    rows = list_analyses(500)
    if not rows:
        st.info("Dashboard metrics will appear after assessments are saved.")
        return

    frame = _portfolio_frame(rows)
    frame["Overall numeric"] = pd.to_numeric(frame["Overall"], errors="coerce").fillna(0.0)
    scores = frame["Overall numeric"]
    best = frame.loc[scores.idxmax()]
    lowest = frame.loc[scores.idxmin()]

    k1, k2, k3, k4, k5 = st.columns(5)
    k1.metric("Saved properties", len(frame))
    k2.metric("Average score", f"{scores.mean():.1f}/10")
    k3.metric("Highest score", f"{scores.max():.1f}/10")
    k4.metric("Lowest score", f"{scores.min():.1f}/10")
    k5.metric("Top property", best["Key"])
    st.caption(f"Top property: {best['Display name']} · Lowest: {lowest['Display name']}")

    def score_band(value: float) -> str:
        if value >= 8:
            return "Excellent (8–10)"
        if value >= 6:
            return "Good (6–7.9)"
        if value >= 4:
            return "Needs review (4–5.9)"
        return "High concern (0–3.9)"

    frame["Score band"] = frame["Overall numeric"].map(score_band)
    band_order = ["Excellent (8–10)", "Good (6–7.9)", "Needs review (4–5.9)", "High concern (0–3.9)"]

    left, right = st.columns(2)
    with left:
        st.markdown("#### Property rankings")
        ranking = frame.sort_values("Overall numeric", ascending=True)
        fig, ax = plt.subplots(figsize=(9, max(4.5, len(ranking) * 0.42)))
        bars = ax.barh(ranking["Key"], ranking["Overall numeric"])
        ax.set_xlim(0, 10)
        ax.set_xlabel("Overall score")
        ax.set_title("All saved properties")
        for bar, value in zip(bars, ranking["Overall numeric"]):
            ax.text(min(value + 0.12, 9.7), bar.get_y() + bar.get_height()/2, f"{value:.1f}", va="center", fontsize=8)
        # The chart legend explains the record keys without requiring horizontal scrolling.
        legend_text = " · ".join(f"{r['Key']} = {r['Display name']}" for _, r in ranking.iterrows())
        ax.plot([], [], label="Property key legend below")
        ax.legend(loc="lower right", frameon=True)
        fig.tight_layout()
        st.pyplot(fig, clear_figure=True)
        with st.expander("Property legend", expanded=True):
            st.dataframe(
                ranking[["Key", "Display name", "Overall numeric"]].rename(columns={"Overall numeric": "Score"}),
                use_container_width=True,
                hide_index=True,
            )

    with right:
        st.markdown("#### Score distribution")
        counts = frame["Score band"].value_counts().reindex(band_order, fill_value=0)
        fig, ax = plt.subplots(figsize=(8, 4.8))
        bars = ax.bar(counts.index, counts.values, label="Saved properties")
        ax.set_ylabel("Number of properties")
        ax.set_title("Portfolio score bands")
        ax.tick_params(axis="x", rotation=25)
        ax.legend(title="Legend", loc="upper right")
        for bar, value in zip(bars, counts.values):
            ax.text(bar.get_x() + bar.get_width()/2, value + 0.05, str(int(value)), ha="center", va="bottom")
        fig.tight_layout()
        st.pyplot(fig, clear_figure=True)

        st.markdown("#### Score trend")
        trend = frame.copy()
        trend["Created datetime"] = pd.to_datetime(trend["Created"], errors="coerce")
        trend = trend.sort_values(["Created datetime", "ID"])
        fig, ax = plt.subplots(figsize=(8, 4.2))
        ax.plot(range(1, len(trend) + 1), trend["Overall numeric"], marker="o", label="Overall score")
        ax.axhline(scores.mean(), linestyle="--", label=f"Portfolio average ({scores.mean():.1f})")
        ax.set_ylim(0, 10)
        ax.set_xlabel("Assessment sequence")
        ax.set_ylabel("Score")
        ax.set_title("Saved assessment trend")
        ax.legend(title="Legend", loc="best")
        fig.tight_layout()
        st.pyplot(fig, clear_figure=True)

    st.divider()
    st.markdown("### All saved properties")
    f1, f2, f3, f4 = st.columns([2, 1, 1, 1])
    query = f1.text_input("Search dashboard properties", placeholder="Property, owner, tags or record key")
    selected_band = f2.selectbox("Score band", ["All"] + band_order)
    status_options = ["All"] + sorted(frame["Status"].fillna("Draft").astype(str).unique().tolist())
    selected_status = f3.selectbox("Status", status_options)
    dashboard_sort = f4.selectbox("Sort dashboard", ["Newest", "Highest score", "Lowest score", "Property name"])

    view = frame.copy()
    if query.strip():
        q = query.strip().lower()
        view = view[view.apply(lambda row: q in " ".join(map(str, row.values)).lower(), axis=1)]
    if selected_band != "All":
        view = view[view["Score band"] == selected_band]
    if selected_status != "All":
        view = view[view["Status"] == selected_status]
    if dashboard_sort == "Highest score":
        view = view.sort_values("Overall numeric", ascending=False)
    elif dashboard_sort == "Lowest score":
        view = view.sort_values("Overall numeric", ascending=True)
    elif dashboard_sort == "Property name":
        view = view.sort_values("Property")
    else:
        view = view.sort_values("ID", ascending=False)

    st.dataframe(
        view[["Key", "Property", "Apartment number", "Owner", "Overall", "Vastu", "Numerology", "Confidence", "Status", "Tags", "Score band", "Created"]],
        use_container_width=True,
        hide_index=True,
        height=min(650, 92 + max(1, len(view)) * 35),
    )
    st.caption(f"Showing {len(view)} of {len(frame)} saved properties.")

    if not view.empty:
        open_id = st.selectbox(
            "Open a saved property",
            view["ID"].tolist(),
            format_func=lambda value: f"P{value} — {frame.loc[frame['ID'] == value, 'Display name'].iloc[0]}",
            key="dashboard_open_id",
        )
        c1, c2 = st.columns(2)
        if c1.button("Open results", type="primary", use_container_width=True):
            saved = get_analysis(int(open_id))
            if saved:
                st.session_state.analysis_result = saved["result"]
                st.session_state.last_payload = saved["payload"]
                st.session_state.last_saved_analysis_id = int(open_id)
                st.session_state.analysis_complete = True
                st.session_state.editing_analysis_id = None
                st.session_state.edit_payload = None
                st.session_state.active_page = "Results"
                st.rerun()
        if c2.button("Edit property", use_container_width=True):
            saved = get_analysis(int(open_id))
            if saved:
                prepare_record_for_edit(int(open_id), saved["payload"])
                st.rerun()


def _navigate() -> None:
    st.session_state.active_page = st.session_state.main_menu


apply_theme(); initialise_session_state()
MENU_OPTIONS=["New assessment","Results","Saved portfolio","Compare properties","Dashboard"]
if st.session_state.get("active_page") not in MENU_OPTIONS: st.session_state.active_page="New assessment"
# Keep the visible menu in sync with programmatic navigation (Load, Edit, New record).
if st.session_state.get("main_menu") != st.session_state.active_page:
    st.session_state.main_menu = st.session_state.active_page
st.sidebar.markdown("## 🧭 VastuAI Professional")
st.sidebar.caption(f"Version {__version__}")
st.sidebar.radio("Main menu",MENU_OPTIONS,index=MENU_OPTIONS.index(st.session_state.active_page),key="main_menu",on_change=_navigate)
st.sidebar.divider()
st.sidebar.button(
    "➕ Add another record",
    type="primary",
    use_container_width=True,
    on_click=start_new_record,
    help="Exit Modify mode and open a completely blank assessment.",
)

st.markdown('<div class="hero"><h1>🧭 VastuAI Professional</h1><p>Assess, manage and compare properties from one workspace.</p></div>',unsafe_allow_html=True)
notice=st.session_state.pop("assessment_notice",None)
if notice:
    if notice.startswith("Assessment completed, but"):
        st.warning(notice)
    else:
        st.success(notice)
with st.expander("Important notice"):
    st.info("This application provides belief-based Vastu and numerology guidance. It is not a substitute for structural inspection, legal due diligence, financial advice or property valuation.")
page=st.session_state.active_page
if page=="New assessment":
    if st.session_state.get("editing_analysis_id"): st.warning(f"Edit mode: P{st.session_state.editing_analysis_id}. Submitting updates this record.")
    render_workflow_steps(); st.divider()
    mode=st.radio("Property input method",["Enter details manually","Upload floor plan"],horizontal=True,key="input_mode",on_change=reset_analysis)
    render_manual_form() if mode=="Enter details manually" else render_layout_upload()
elif page=="Results":
    if st.session_state.analysis_complete and st.session_state.analysis_result: render_results(st.session_state.analysis_result,st.session_state.last_payload or {})
    else: st.info("No assessment loaded. Create one or load a saved record.")
elif page=="Saved portfolio": render_portfolio()
elif page=="Compare properties": render_comparison()
elif page=="Dashboard": render_dashboard()
if os.getenv("OPENAI_API_KEY"):
    st.sidebar.success("OpenAI vision enabled")
else:
    st.sidebar.warning("OPENAI_API_KEY is not configured")

st.divider()
st.caption(
    f"VastuAI Professional v{__version__} · Belief-based guidance only · "
    "Always complete structural, legal, safety and financial due diligence."
)
