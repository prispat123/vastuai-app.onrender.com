from __future__ import annotations

import os
import socket
import subprocess
import sys
import time
import webbrowser
from pathlib import Path

HOST = "127.0.0.1"
PORT = int(os.getenv("STREAMLIT_PORT", "8501"))
ROOT = Path(__file__).resolve().parent
URL = f"http://{HOST}:{PORT}"


def port_is_open() -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.25)
        return sock.connect_ex((HOST, PORT)) == 0


def main() -> int:
    command = [
        sys.executable,
        "-m",
        "streamlit",
        "run",
        str(ROOT / "app.py"),
        "--server.address",
        HOST,
        "--server.port",
        str(PORT),
        "--server.headless",
        "true",
        "--browser.gatherUsageStats",
        "false",
    ]
    print(f"Starting VastuAI Professional at {URL}")
    process = subprocess.Popen(command, cwd=ROOT)
    try:
        for _ in range(80):
            if process.poll() is not None:
                return int(process.returncode or 1)
            if port_is_open():
                webbrowser.open_new_tab(URL)
                print("Browser opened. If it does not appear, open:", URL)
                break
            time.sleep(0.25)
        return process.wait()
    except KeyboardInterrupt:
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
