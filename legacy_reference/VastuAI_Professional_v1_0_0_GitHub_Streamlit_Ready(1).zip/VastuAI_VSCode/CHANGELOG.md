# Changelog

## 1.0.0 — Production release candidate

- Prepared repository for GitHub and Streamlit Community Cloud.
- Added Streamlit Secrets support while retaining local `.env` support.
- Added deployment configuration and Tesseract system dependency.
- Added version display, deployment documentation, security and privacy notes.
- Hardened `.gitignore` for keys, databases, caches, logs and generated exports.
- Retained the Sprint 3.2 visual reports, exports, portfolio and comparison features.
