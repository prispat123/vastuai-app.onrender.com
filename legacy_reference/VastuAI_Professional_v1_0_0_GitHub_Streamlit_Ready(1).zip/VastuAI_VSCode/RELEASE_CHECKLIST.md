# VastuAI Professional v1.0.0 Release Checklist

## Before pushing to GitHub

- [ ] Confirm the repository is private unless source publication is intentional.
- [ ] Run `python -m pytest -q`.
- [ ] Run the application locally and complete one manual assessment.
- [ ] Test one floor-plan upload with a temporary API key.
- [ ] Confirm `.env` and `.streamlit/secrets.toml` are absent from `git status`.
- [ ] Confirm `data/vastuai.db`, cache files, logs, and generated exports are absent.
- [ ] Review copyright, privacy, disclaimer, and contact wording.

## Streamlit deployment

- [ ] Select Python 3.12.
- [ ] Set the entrypoint to `app.py`.
- [ ] Add OpenAI values through Streamlit Secrets.
- [ ] Confirm the deployed app opens without an API key appearing in logs.
- [ ] Test manual assessment, floor-plan analysis, PDF generation, and ZIP export.
- [ ] Confirm users understand that Community Cloud portfolio storage is temporary.

## Before wider public use

- [ ] Add authentication.
- [ ] Move portfolio data to a managed database.
- [ ] Add a public privacy notice and support contact.
- [ ] Add usage limits or billing controls for OpenAI API calls.
- [ ] Add monitoring, error tracking, backups, and a deletion workflow.
