# VastuAI Professional

VastuAI Professional is a Streamlit workspace for belief-based Vastu and numerology assessments. It supports manual property entry, AI-assisted floor-plan extraction, editable room directions, weighted scoring, saved-property comparison, professional PDF reporting, and export packages.

> **Important:** Vastu and numerology are traditional belief systems and are not scientifically validated property-evaluation methods. This application does not replace structural inspection, legal due diligence, fire and safety review, financial advice, valuation, or professional real-estate advice.

## Version

**v1.0.0 — production release candidate**

## Main capabilities

- Manual assessment and floor-plan upload workflows
- PNG, JPG, JPEG, and first-page PDF processing
- Strict North-reference validation with manual orientation fallback
- GPT vision room and direction extraction
- Editable extraction review before scoring
- Configurable Vastu rules stored in JSON
- Weighted Vastu scoring, grades, confidence, severity, and remedies
- Configurable numerology assessment
- Deterministic recommendation engine with optional AI-written summary
- SQLite-backed saved-property portfolio
- Search, filtering, editing, duplication, deletion, ranking, and comparison
- Professional PDF, JSON, text, CSV, chart, and ZIP exports
- Directional balance wheel and room-score charts

## Repository structure

```text
VastuAI-Professional/
├── app.py
├── graph.py
├── state.py
├── version.py
├── agents/
├── services/
├── utils/
├── config/
├── tests/
├── data/
├── exports/
├── logs/
├── .streamlit/
├── requirements.txt
├── packages.txt
├── DEPLOYMENT.md
├── SECURITY.md
└── PRIVACY.md
```

## Local installation

Python 3.12 is recommended to match Streamlit Community Cloud.

### Windows PowerShell

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
Copy-Item .env.example .env
python -m pytest -q
python -m streamlit run app.py
```

You may also run `Start_VastuAI.bat` after dependencies are installed.

### macOS or Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
cp .env.example .env
python -m pytest -q
python -m streamlit run app.py
```

For local OCR, install the Tesseract binary separately. OCR is optional; vision analysis continues when Tesseract is unavailable.

## Configuration

Local `.env`:

```env
OPENAI_API_KEY=your_openai_api_key_here
OPENAI_MODEL=gpt-5
OPENAI_VISION_MODEL=gpt-4.1-mini
```

Alternatively, copy `.streamlit/secrets.example.toml` to `.streamlit/secrets.toml`. Never commit either your `.env` or `secrets.toml`.

## Streamlit deployment

See [DEPLOYMENT.md](DEPLOYMENT.md) for the complete GitHub and Streamlit Community Cloud procedure.

Use these Streamlit secrets:

```toml
OPENAI_API_KEY = "your_real_key"
OPENAI_MODEL = "gpt-5"
OPENAI_VISION_MODEL = "gpt-4.1-mini"
```

## Data storage

The local application creates:

- `data/vastuai.db` — saved assessments
- `data/floorplan_cache/` — processed floor-plan cache
- `logs/vastuai.log` — application log
- `exports/` — generated exports

These paths are excluded from Git. Streamlit Community Cloud storage is not intended as durable production storage, so portfolio records can be lost after a restart or redeployment. A managed database and authentication are required before using this as a durable multi-user service.

## Testing

```bash
python -m pytest -q
```

GitHub Actions also runs the test suite on pushes and pull requests to `main`.

## Privacy and security

Uploaded floor plans are sent to the configured OpenAI API for analysis. Only upload plans you are authorized to process. Review [SECURITY.md](SECURITY.md) and [PRIVACY.md](PRIVACY.md) before sharing the application publicly.

## License

Proprietary. See [LICENSE.md](LICENSE.md).
