# Proprietary License

Copyright © 2026 VastuAI Professional. All rights reserved.

This source code and its accompanying assets are proprietary. No permission is
granted to copy, modify, distribute, sublicense, sell, or create derivative works
without prior written authorization from the copyright holder.
