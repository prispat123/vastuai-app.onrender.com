from __future__ import annotations

from state import PropertyState


def rating(score: float) -> str:
    if score >= 8.5: return "Excellent"
    if score >= 7.0: return "Good"
    if score >= 5.5: return "Moderate"
    return "Needs careful review"


def scoring_agent(state: PropertyState) -> dict:
    errors = state.get("validation_errors", [])
    if errors:
        return {"final_result": {"score": 0.0, "rating": "Input error", "errors": errors}}

    vastu = state.get("vastu_result", {})
    numerology = state.get("numerology_result", {})
    vs = vastu.get("score")
    ns = numerology.get("score")

    if vs is not None and ns is not None:
        overall = round(float(vs) * 0.65 + float(ns) * 0.35, 1)
        basis = "Vastu and numerology"
    elif vs is not None:
        overall, basis = float(vs), "Vastu only"
    elif ns is not None:
        overall, basis = float(ns), "Numerology only"
    else:
        return {"final_result": {"score": 0.0, "rating": "Insufficient information"}}

    return {"final_result": {"score": overall, "rating": rating(overall), "basis": basis}}
