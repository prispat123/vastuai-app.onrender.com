from __future__ import annotations

import base64
import json
import os
from typing import Any

from openai import OpenAI


ALLOWED_DIRECTIONS = {
    "North", "North-East", "East", "South-East", "South",
    "South-West", "West", "North-West", "Centre", "Unknown",
}

ROOM_KEYS = (
    "entrance_direction",
    "kitchen_direction",
    "master_bedroom_direction",
    "toilet_direction",
    "pooja_direction",
    "living_room_direction",
    "balcony_direction",
    "staircase_direction",
)


def _normalise_direction(value: Any) -> str:
    text = str(value or "Unknown").strip().title().replace("Northeast", "North-East")
    text = text.replace("Southeast", "South-East").replace("Southwest", "South-West")
    text = text.replace("Northwest", "North-West")
    return text if text in ALLOWED_DIRECTIONS else "Unknown"


def inspect_floor_plan(
    image_bytes: bytes,
    detail: str = "high",
    north_orientation: str = "Auto-detect",
) -> dict[str, Any]:
    """Use an OpenAI vision-capable model to validate and extract a floor plan."""
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not api_key:
        raise RuntimeError(
            "OPENAI_API_KEY is required for automatic North-arrow detection and layout extraction."
        )

    model = os.getenv("OPENAI_VISION_MODEL", "gpt-4.1-mini").strip() or "gpt-4.1-mini"
    data_url = "data:image/png;base64," + base64.b64encode(image_bytes).decode("ascii")

    prompt = """
You are validating a residential floor plan for a Vastu assessment.
Return JSON only.
The user-selected North orientation is: __NORTH_ORIENTATION__. If it is not Auto-detect, treat that page edge as North and do not require a printed North arrow.

Hard rules:
1. Decide whether the image is genuinely a floor plan.
2. A printed or clearly drawn North arrow/compass is compulsory.
3. Do not infer North from page orientation, text orientation, sunlight, roads, or convention.
4. Set north_detected=false when the North reference is absent, cropped, ambiguous, or unreadable.
5. Only derive room directions when North is clearly detected.
6. Use only: North, North-East, East, South-East, South, South-West, West, North-West, Centre, Unknown.
7. Confidence values must be between 0 and 1.
8. Do not invent rooms that are not visible.

Return this exact object shape:
{
  "is_floor_plan": true,
  "north_detected": true,
  "north_confidence": 0.0,
  "north_description": "",
  "vision_quality_score": 0,
  "issues": [],
  "rooms": {
    "entrance_direction": {"value": "Unknown", "confidence": 0.0},
    "kitchen_direction": {"value": "Unknown", "confidence": 0.0},
    "master_bedroom_direction": {"value": "Unknown", "confidence": 0.0},
    "toilet_direction": {"value": "Unknown", "confidence": 0.0},
    "pooja_direction": {"value": "Unknown", "confidence": 0.0},
    "living_room_direction": {"value": "Unknown", "confidence": 0.0},
    "balcony_direction": {"value": "Unknown", "confidence": 0.0},
    "staircase_direction": {"value": "Unknown", "confidence": 0.0}
  },
  "notes": ""
}
""".strip().replace("__NORTH_ORIENTATION__", north_orientation)

    client = OpenAI(api_key=api_key)
    response = client.chat.completions.create(
        model=model,
        messages=[
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {"url": data_url, "detail": detail}},
                ],
            }
        ],
        response_format={"type": "json_object"},
        temperature=0,
    )

    content = response.choices[0].message.content or "{}"
    parsed = json.loads(content)
    rooms = parsed.get("rooms") if isinstance(parsed.get("rooms"), dict) else {}

    normalised_rooms: dict[str, dict[str, Any]] = {}
    for key in ROOM_KEYS:
        item = rooms.get(key, {}) if isinstance(rooms.get(key), dict) else {}
        confidence = max(0.0, min(1.0, float(item.get("confidence", 0.0) or 0.0)))
        value = _normalise_direction(item.get("value"))
        if confidence < 0.60:
            value = "Unknown"
        normalised_rooms[key] = {"value": value, "confidence": confidence}

    return {
        "is_floor_plan": bool(parsed.get("is_floor_plan", False)),
        "north_detected": bool(parsed.get("north_detected", False)),
        "north_confidence": max(
            0.0, min(1.0, float(parsed.get("north_confidence", 0.0) or 0.0))
        ),
        "north_description": str(parsed.get("north_description", "")).strip(),
        "vision_quality_score": int(parsed.get("vision_quality_score", 0) or 0),
        "issues": [str(x) for x in parsed.get("issues", []) if str(x).strip()],
        "rooms": normalised_rooms,
        "notes": str(parsed.get("notes", "")).strip(),
        "model": model,
    }
