from __future__ import annotations

import json
import os

from openai import OpenAI

from state import PropertyState


def fallback_explanation(state: PropertyState) -> str:
    final = state.get("final_result", {})
    vastu = state.get("vastu_result", {})
    numerology = state.get("numerology_result", {})
    recommendation = state.get("recommendation_result", {})

    lines = [
        f"Overall assessment: {final.get('score', 0)}/10 ({final.get('rating', 'Not rated')}).",
        f"Decision guidance: {recommendation.get('decision', 'Review the detailed findings')}.",
    ]
    if vastu.get("score") is not None:
        lines.append(f"Vastu scored {vastu.get('score')}/10 with {vastu.get('coverage', 0)}% coverage.")
    if numerology.get("score") is not None:
        lines.append(f"Numerology scored {numerology.get('score')}/10; the property root number is {numerology.get('property_root_number', 'N/A')}.")
    strengths = recommendation.get("strengths", [])
    cautions = recommendation.get("cautions", [])
    if strengths:
        lines.append("Key strengths: " + " ".join(strengths[:3]))
    if cautions:
        lines.append("Priority cautions: " + " ".join(cautions[:3]))
    actions = recommendation.get("actions", [])
    if actions:
        lines.append("First action: " + str(actions[0].get("practical_action", "Review the highest-priority issue.")))
    lines.append("This is belief-based guidance, not structural, legal, financial, scientific or investment advice.")
    return "\n\n".join(lines)


def explanation_agent(state: PropertyState) -> dict:
    if state.get("validation_errors"):
        return {"explanation": "Correct the input errors and run the assessment again."}

    fallback = fallback_explanation(state)
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not api_key:
        return {"explanation": fallback}

    model = os.getenv("OPENAI_MODEL", "gpt-5").strip() or "gpt-5"
    compact = {
        "owner": state.get("owner_name", ""),
        "property_number": state.get("flat_number", ""),
        "overall": state.get("final_result", {}),
        "vastu": state.get("vastu_result", {}),
        "numerology": state.get("numerology_result", {}),
        "recommendation": state.get("recommendation_result", {}),
    }
    prompt = """
You are writing a professional, belief-based property compatibility summary.
Use the supplied structured assessment. Write 250-350 words with these headings:
Overall assessment, Key strengths, Priority concerns, Practical next steps, Important limitation.
Be balanced and specific. Do not invent facts, guarantee outcomes, or claim scientific certainty.
State that physical layout findings should take priority over numerology for property decisions.
""".strip() + "\n\nDATA:\n" + json.dumps(compact, ensure_ascii=False, default=str)

    try:
        client = OpenAI(api_key=api_key, base_url=os.getenv("OPENAI_BASE_URL") or None)
        response = client.responses.create(model=model, input=prompt)
        text = (response.output_text or "").strip()
        return {"explanation": text if text else fallback}
    except Exception:
        return {"explanation": fallback}
