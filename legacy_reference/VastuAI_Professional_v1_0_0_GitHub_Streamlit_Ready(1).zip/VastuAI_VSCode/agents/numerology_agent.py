from __future__ import annotations

from datetime import date

from state import PropertyState
from utils.numerology import calculate_numerology


def numerology_agent(state: PropertyState) -> dict:
    if state.get("validation_errors"):
        return {"numerology_result": {}}
    readiness = state.get("analysis_readiness", {})
    if not readiness.get("numerology_ready"):
        return {"numerology_result": {}}

    result = calculate_numerology(
        owner_name=state.get("owner_name", ""),
        dob=date.fromisoformat(state["dob"]),
        flat_number=state["flat_number"],
        assessment_year=state.get("assessment_year"),
    )
    return {"numerology_result": result}
