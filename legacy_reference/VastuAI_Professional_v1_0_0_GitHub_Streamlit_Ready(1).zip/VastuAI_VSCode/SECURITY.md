# Security

- Never commit `.env` or `.streamlit/secrets.toml`.
- Store the OpenAI API key in Streamlit Community Cloud Secrets.
- Rotate the key immediately if it is exposed.
- Use a private GitHub repository unless you intentionally want to publish the source.
- Uploaded floor plans are sent to the configured OpenAI API for analysis. Do not upload confidential plans without appropriate permission.
- The local SQLite portfolio is not an authentication or multi-user security boundary.
