from __future__ import annotations
import logging
from pathlib import Path

LOG_PATH = Path(__file__).resolve().parents[1] / "logs" / "vastuai.log"
LOG_PATH.parent.mkdir(parents=True, exist_ok=True)


def get_logger() -> logging.Logger:
    logger = logging.getLogger("vastuai")
    if not logger.handlers:
        logger.setLevel(logging.INFO)
        handler = logging.FileHandler(LOG_PATH, encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
        logger.addHandler(handler)
    return logger
