from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

DB_PATH = Path(__file__).resolve().parents[1] / "data" / "vastuai.db"


def _connection() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS analyses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            property_label TEXT NOT NULL,
            owner_name TEXT,
            flat_number TEXT,
            overall_score REAL,
            vastu_score REAL,
            numerology_score REAL,
            confidence TEXT,
            payload_json TEXT NOT NULL,
            result_json TEXT NOT NULL,
            workflow_status TEXT DEFAULT 'Draft',
            tags TEXT DEFAULT '',
            consultant_notes TEXT DEFAULT ''
        )
        """
    )
    columns = {row[1] for row in conn.execute("PRAGMA table_info(analyses)").fetchall()}
    migrations = {
        "workflow_status": "ALTER TABLE analyses ADD COLUMN workflow_status TEXT DEFAULT 'Draft'",
        "tags": "ALTER TABLE analyses ADD COLUMN tags TEXT DEFAULT ''",
        "consultant_notes": "ALTER TABLE analyses ADD COLUMN consultant_notes TEXT DEFAULT ''",
    }
    for column, statement in migrations.items():
        if column not in columns:
            conn.execute(statement)
    return conn


def save_analysis(payload: dict[str, Any], result: dict[str, Any]) -> int:
    final = result.get("final_result", {})
    vastu = result.get("vastu_result", {})
    numerology = result.get("numerology_result", {})
    recommendation = result.get("recommendation_result", {})
    label = str(payload.get("property_name") or payload.get("flat_number") or "Unnamed property")
    with _connection() as conn:
        cursor = conn.execute(
            """
            INSERT INTO analyses (
                created_at, property_label, owner_name, flat_number,
                overall_score, vastu_score, numerology_score, confidence,
                payload_json, result_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                datetime.now(timezone.utc).isoformat(),
                label,
                payload.get("owner_name", ""),
                payload.get("flat_number", ""),
                float(final.get("score", 0) or 0),
                float(vastu.get("score", 0) or 0) if vastu else None,
                float(numerology.get("score", 0) or 0) if numerology else None,
                recommendation.get("confidence") or vastu.get("confidence") or "N/A",
                json.dumps(payload, ensure_ascii=False, default=str),
                json.dumps(result, ensure_ascii=False, default=str),
            ),
        )
        return int(cursor.lastrowid)


def update_analysis(analysis_id: int, payload: dict[str, Any], result: dict[str, Any]) -> None:
    final = result.get("final_result", {})
    vastu = result.get("vastu_result", {})
    numerology = result.get("numerology_result", {})
    recommendation = result.get("recommendation_result", {})
    label = str(payload.get("property_name") or payload.get("flat_number") or "Unnamed property")
    with _connection() as conn:
        conn.execute(
            """
            UPDATE analyses SET
                property_label = ?, owner_name = ?, flat_number = ?,
                overall_score = ?, vastu_score = ?, numerology_score = ?,
                confidence = ?, payload_json = ?, result_json = ?
            WHERE id = ?
            """,
            (
                label,
                payload.get("owner_name", ""),
                payload.get("flat_number", ""),
                float(final.get("score", 0) or 0),
                float(vastu.get("score", 0) or 0) if vastu else None,
                float(numerology.get("score", 0) or 0) if numerology else None,
                recommendation.get("confidence") or vastu.get("confidence") or "N/A",
                json.dumps(payload, ensure_ascii=False, default=str),
                json.dumps(result, ensure_ascii=False, default=str),
                int(analysis_id),
            ),
        )


def list_analyses(limit: int = 100) -> list[dict[str, Any]]:
    with _connection() as conn:
        rows = conn.execute(
            "SELECT * FROM analyses ORDER BY id DESC LIMIT ?", (int(limit),)
        ).fetchall()
    return [dict(row) for row in rows]


def get_analysis(analysis_id: int) -> dict[str, Any] | None:
    with _connection() as conn:
        row = conn.execute("SELECT * FROM analyses WHERE id = ?", (int(analysis_id),)).fetchone()
    if row is None:
        return None
    item = dict(row)
    item["payload"] = json.loads(item.pop("payload_json"))
    item["result"] = json.loads(item.pop("result_json"))
    return item


def delete_analysis(analysis_id: int) -> None:
    with _connection() as conn:
        conn.execute("DELETE FROM analyses WHERE id = ?", (int(analysis_id),))


def update_metadata(analysis_id: int, workflow_status: str, tags: str, consultant_notes: str) -> None:
    with _connection() as conn:
        conn.execute(
            "UPDATE analyses SET workflow_status = ?, tags = ?, consultant_notes = ? WHERE id = ?",
            (workflow_status.strip() or "Draft", tags.strip(), consultant_notes.strip(), int(analysis_id)),
        )
