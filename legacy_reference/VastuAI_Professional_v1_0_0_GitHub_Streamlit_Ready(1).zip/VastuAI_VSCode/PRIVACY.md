# Privacy Notes

VastuAI Professional processes user-entered property information and may send uploaded
floor-plan images to the configured OpenAI API for visual analysis. The application
also stores assessment records in a local SQLite database.

Before public use, provide users with a privacy notice describing:

- what information is collected;
- why floor plans are processed;
- the third-party AI service used;
- retention and deletion practices;
- who can access saved assessments; and
- a contact route for privacy requests.

Streamlit Community Cloud's local filesystem should not be treated as durable production storage.
