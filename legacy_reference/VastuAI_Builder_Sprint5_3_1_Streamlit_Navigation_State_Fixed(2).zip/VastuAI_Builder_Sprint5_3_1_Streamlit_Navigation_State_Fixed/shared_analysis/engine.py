from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any

from services.gpt_vision import VisionSettings, analyse_single_apartment
from services.professional_vastu import score_apartment

DIRECTIONS = ["North", "North-East", "East", "South-East", "South", "South-West", "West", "North-West", "Centre", "Unknown"]
PAGE_NORTHS = ["Top", "Right", "Bottom", "Left"]


def analyse_layout(image_path: Path, settings: VisionSettings | None = None) -> tuple[dict[str, Any], str]:
    """Canonical vision + rules pipeline shared by both products."""
    apartment, raw = analyse_single_apartment(image_path, settings)
    apartment["analysis_engine"] = "VastuAI Shared Analysis Engine v1"
    apartment["ui_independent"] = True
    return apartment, raw


def run_vastu_analysis(apartment: dict[str, Any]) -> dict[str, Any]:
    result = score_apartment(apartment)
    if result:
        result["analysis_engine"] = "VastuAI Shared Analysis Engine v1"
    return result


def _screen_direction(cx: float, cy: float) -> str:
    dx, dy = cx - 0.5, 0.5 - cy
    if abs(dx) < 0.08 and abs(dy) < 0.08:
        return "Centre"
    import math
    angle = (math.degrees(math.atan2(dx, dy)) + 360) % 360
    sectors = ["North", "North-East", "East", "South-East", "South", "South-West", "West", "North-West"]
    return sectors[int((angle + 22.5) // 45) % 8]


def _rotate_direction(screen_direction: str, page_north: str) -> str:
    if screen_direction in {"Centre", "Unknown"}:
        return screen_direction
    order = ["North", "North-East", "East", "South-East", "South", "South-West", "West", "North-West"]
    offsets = {"Top": 0, "Right": -2, "Bottom": -4, "Left": -6}
    return order[(order.index(screen_direction) + offsets[page_north]) % 8]


def apply_manual_overrides(
    apartment: dict[str, Any], *, page_north: str | None = None,
    entrance_direction: str | None = None,
) -> dict[str, Any]:
    """Apply audited manual North/entrance corrections and immediately re-score."""
    updated = deepcopy(apartment)
    audit = list(updated.get("manual_override_audit", []))

    if page_north:
        if page_north not in PAGE_NORTHS:
            raise ValueError(f"Unsupported page North: {page_north}")
        updated.update({
            "north_detected": True,
            "north_direction": "North",
            "north_source": "manual",
            "north_page_position": page_north,
            "north_description": f"User confirmed North points to the {page_north.lower()} of the page.",
            "north_confidence": 1.0,
        })
        for room in updated.get("rooms", []):
            if not isinstance(room, dict):
                continue
            centre = room.get("centre") if isinstance(room.get("centre"), dict) else {}
            try:
                cx, cy = float(centre.get("x")), float(centre.get("y"))
            except (TypeError, ValueError):
                continue
            room["direction"] = _rotate_direction(_screen_direction(cx, cy), page_north)
            room["zone"] = room["direction"]
            room["direction_source"] = "manual-north geometry"
            room["confidence"] = 1.0
        audit.append({"field": "north", "value": page_north, "source": "manual"})

    if entrance_direction:
        if entrance_direction not in DIRECTIONS[:-1]:
            raise ValueError(f"Unsupported entrance direction: {entrance_direction}")
        updated["entrance_direction"] = entrance_direction
        updated["entrance_source"] = "manual"
        updated["entrance_confidence"] = 1.0
        audit.append({"field": "entrance_direction", "value": entrance_direction, "source": "manual"})

    updated["manual_override_audit"] = audit
    updated["vastu_result"] = run_vastu_analysis(updated)
    updated["analysis_engine"] = "VastuAI Shared Analysis Engine v1"
    return updated


def apply_room_overrides(apartment: dict[str, Any], room_rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Replace/edit room directions from the visual review workspace and re-score.

    Existing room geometry is retained where a matching room name/type exists. New rows
    are allowed so a reviewer can add a missed room. All edited values are marked manual.
    """
    updated = deepcopy(apartment)
    existing = [r for r in updated.get("rooms", []) if isinstance(r, dict)]
    by_key = {}
    for r in existing:
        key = (str(r.get("name", "")).strip().lower(), str(r.get("room_type", "")).strip().lower())
        by_key[key] = r

    cleaned = []
    audit = list(updated.get("manual_override_audit", []))
    for item in room_rows:
        if not isinstance(item, dict):
            continue
        name = str(item.get("Room", item.get("name", ""))).strip()
        room_type = str(item.get("Type", item.get("room_type", ""))).strip()
        direction = str(item.get("Direction", item.get("direction", "Unknown"))).strip() or "Unknown"
        if not name and not room_type:
            continue
        if direction not in DIRECTIONS:
            raise ValueError(f"Unsupported room direction: {direction}")
        key = (name.lower(), room_type.lower())
        room = deepcopy(by_key.get(key, {}))
        old_direction = room.get("direction", "Unknown")
        room.update({
            "name": name or room_type,
            "room_type": room_type or name,
            "direction": direction,
            "zone": direction,
            "direction_source": "manual",
            "confidence": 1.0,
        })
        cleaned.append(room)
        if old_direction != direction or key not in by_key:
            audit.append({"field": "room_direction", "room": name or room_type, "value": direction, "source": "manual"})

    updated["rooms"] = cleaned
    updated["manual_override_audit"] = audit
    updated["vastu_result"] = run_vastu_analysis(updated)
    updated["analysis_engine"] = "VastuAI Shared Analysis Engine v1"
    return updated
