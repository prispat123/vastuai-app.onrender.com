from pathlib import Path
from services import db
from services.storage import data_root, uploads_root
from services.assets import project_assets_root


def test_permanent_project_delete_removes_rows_and_project_folders(tmp_path, monkeypatch):
    # db.DB_PATH is module-level; point it to an isolated test database.
    monkeypatch.setattr(db, "DB_PATH", tmp_path / "database" / "test.db")
    monkeypatch.setenv("VASTUAI_DATA_DIR", str(tmp_path))
    db.init_db()
    pid = db.create_project("Delete Me", "Builder")

    upload_dir = uploads_root() / f"project_{pid}"
    upload_dir.mkdir(parents=True, exist_ok=True)
    (upload_dir / "source.pdf").write_bytes(b"pdf")
    asset_dir = project_assets_root(pid)
    (asset_dir / "marker.txt").write_text("asset", encoding="utf-8")

    result = db.delete_project_permanently(pid)

    assert result["project_name"] == "Delete Me"
    assert db.get_project(pid) is None
    assert not upload_dir.exists()
    assert not asset_dir.exists()


def test_delete_unknown_project_is_safe(tmp_path, monkeypatch):
    monkeypatch.setattr(db, "DB_PATH", tmp_path / "database" / "test.db")
    monkeypatch.setenv("VASTUAI_DATA_DIR", str(tmp_path))
    db.init_db()
    try:
        db.delete_project_permanently(999999)
    except ValueError as exc:
        assert "not found" in str(exc).lower()
    else:
        raise AssertionError("Expected ValueError")
