from shared_analysis.engine import apply_room_overrides


def test_manual_room_overrides_preserve_geometry_and_rescore():
    apartment = {
        "north_direction": "North",
        "entrance_direction": "East",
        "rooms": [
            {"name": "Kitchen", "room_type": "Kitchen", "direction": "West", "centre": {"x": .8, "y": .8}},
        ],
    }
    updated = apply_room_overrides(apartment, [
        {"Room": "Kitchen", "Type": "Kitchen", "Direction": "South-East"},
        {"Room": "Master Bedroom", "Type": "Bedroom", "Direction": "South-West"},
    ])
    assert updated["rooms"][0]["direction"] == "South-East"
    assert updated["rooms"][0]["centre"] == {"x": .8, "y": .8}
    assert updated["rooms"][0]["direction_source"] == "manual"
    assert updated["rooms"][1]["name"] == "Master Bedroom"
    assert "vastu_result" in updated
