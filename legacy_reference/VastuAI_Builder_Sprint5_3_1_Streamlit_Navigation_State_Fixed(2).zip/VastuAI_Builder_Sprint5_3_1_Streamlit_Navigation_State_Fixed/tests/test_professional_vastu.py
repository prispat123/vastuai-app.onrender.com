from services.professional_vastu import score_apartment, map_rooms_to_professional_fields

def test_maps_and_scores_like_professional():
    apartment={"entrance_direction":"North-East","rooms":[
        {"name":"Kitchen","room_type":"Kitchen","direction":"South-East"},
        {"name":"Master Bedroom","room_type":"Master Bedroom","direction":"South-West"},
        {"name":"Living","room_type":"Living Room","direction":"North-East"},
        {"name":"Toilet","room_type":"Toilet","direction":"North-West"},
    ]}
    fields=map_rooms_to_professional_fields(apartment)
    assert fields["kitchen_direction"]=="South-East"
    result=score_apartment(apartment)
    assert result["score"] >= 9
    assert result["algorithm"].startswith("VastuAI Professional")
