import json
from services.reports import apartment_report_pdf, project_report_pdf

class Row(dict):
    pass

def test_pdf_reports_are_generated(tmp_path):
    row=Row(tower='T1',floor='1',apartment_code='101',apartment_type='2BHK',page_number=1,layout_image_path='',page_image_path='',extracted_text=json.dumps({'apartment':{'north_direction':'North','entrance_direction':'East','vastu_result':{'score':8.2,'percentage':82,'grade':'A','status':'Favourable','coverage':40,'confidence':'Moderate','details':[],'strengths':['Good entrance.'],'cautions':[]}}}))
    project={'project_name':'Demo','builder_name':'Builder','location':'Pune'}
    assert apartment_report_pdf(project,row).startswith(b'%PDF')
    assert project_report_pdf(project,[row]).startswith(b'%PDF')
