from services.exports import inventory_dataframe,to_excel_bytes
def test_empty():assert list(inventory_dataframe([]).columns)==['Tower','Floor','Apartment','Type','Status','Source PDF','Page']
def test_excel():
 rows=[{'tower':'A','floor':'1','apartment_code':'A101','apartment_type':'2BHK','review_status':'Ready','original_name':'a.pdf','page_number':1}]
 assert len(to_excel_bytes(inventory_dataframe(rows)))>1000
