import json
from pathlib import Path

from services.assets import persist_apartment_assets


def test_persist_apartment_assets_copies_image_and_json(tmp_path, monkeypatch):
    monkeypatch.setenv("VASTUAI_DATA_DIR", str(tmp_path / "data"))
    source = tmp_path / "page.jpg"
    source.write_bytes(b"sample-layout-image")
    payload = {"apartment": {"tower": "T1", "apartment_code": "11"}}

    result = persist_apartment_assets(7, "fixed-uuid", source, json.dumps(payload))

    layout = Path(result["layout_image_path"])
    analysis = Path(result["analysis_json_path"])
    assert layout.exists()
    assert layout.read_bytes() == source.read_bytes()
    assert analysis.exists()
    assert json.loads(analysis.read_text(encoding="utf-8")) == payload
    assert "project_7" in str(layout)
    assert "fixed-uuid" in str(layout)
