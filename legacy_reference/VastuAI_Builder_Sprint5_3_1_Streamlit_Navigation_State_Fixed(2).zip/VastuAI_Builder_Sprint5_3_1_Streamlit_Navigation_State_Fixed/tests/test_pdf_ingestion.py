from pathlib import Path

from services.gpt_vision import analyse_single_apartment


def test_detail_normalizes_decimal_bhk(monkeypatch, tmp_path: Path):
    image = tmp_path / "page.jpg"
    image.write_bytes(b"fake")
    monkeypatch.setattr(
        "services.gpt_vision._request_json",
        lambda **kwargs: ({
            "tower": "T1", "floor": "11-16", "apartment_code": "12",
            "apartment_type": "2,5 BHK", "north_direction": "North",
            "entrance_direction": "East", "rooms": [], "confidence": 0.9,
            "notes": ""
        }, "{}"),
    )
    result, _ = analyse_single_apartment(image)
    assert result["apartment_code"] == "12"
    assert result["apartment_type"] == "2.5BHK"
