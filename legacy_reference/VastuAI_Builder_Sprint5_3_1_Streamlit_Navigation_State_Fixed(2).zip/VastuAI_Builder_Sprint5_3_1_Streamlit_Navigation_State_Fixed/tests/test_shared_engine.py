from shared_analysis.engine import apply_manual_overrides


def test_manual_north_recalculates_rooms_and_scores():
    apartment={
        "north_detected":False,"north_direction":"Unknown","entrance_direction":"Unknown",
        "rooms":[
            {"name":"Kitchen","room_type":"Kitchen","centre":{"x":0.8,"y":0.2},"direction":"Unknown"},
            {"name":"Master Bedroom","room_type":"Master Bedroom","centre":{"x":0.2,"y":0.8},"direction":"Unknown"},
        ],
    }
    result=apply_manual_overrides(apartment,page_north="Top",entrance_direction="East")
    assert result["north_source"] == "manual"
    assert result["north_confidence"] == 1.0
    assert result["entrance_source"] == "manual"
    assert result["rooms"][0]["direction"] == "North-East"
    assert result["rooms"][1]["direction"] == "South-West"
    assert result["vastu_result"]["analysis_engine"] == "VastuAI Shared Analysis Engine v1"


def test_manual_north_rotation_right():
    apartment={"rooms":[{"name":"Living","room_type":"Living Room","centre":{"x":0.5,"y":0.1}}]}
    result=apply_manual_overrides(apartment,page_north="Right")
    assert result["rooms"][0]["direction"] == "West"
