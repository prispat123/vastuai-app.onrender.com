import json
from pathlib import Path

from services import gpt_vision
from services.snapshots import room_inventory_csv_bytes


def test_room_extraction_normalizes_fields(monkeypatch, tmp_path):
    image = tmp_path / "layout.jpg"
    image.write_bytes(b"image")

    def fake_request_json(**kwargs):
        return ({
            "tower": "T1", "floor": "11", "apartment_code": "11", "apartment_type": "2,5 BHK",
            "north_direction": "North", "entrance_direction": "East",
            "rooms": [{
                "name": "Kitchen", "room_type": "Kitchen", "direction": "South-East",
                "confidence": 1.2,
                "bbox": {"x": -0.1, "y": 0.2, "width": 1.4, "height": 0.3},
                "centre": {"x": 0.8, "y": 0.35},
            }],
            "confidence": 0.9, "notes": "ok"
        }, "raw")

    monkeypatch.setattr(gpt_vision, "_request_json", fake_request_json)
    result, _ = gpt_vision.analyse_single_apartment(image)
    assert result["apartment_type"] == "2.5BHK"
    assert result["rooms"][0]["direction"] == "South-East"
    assert result["rooms"][0]["confidence"] == 1.0
    assert result["rooms"][0]["bbox"]["x"] == 0.0
    assert result["rooms"][0]["bbox"]["width"] == 1.0


def test_room_level_csv_contains_coordinates():
    rows = [{
        "builder_name": "Builder", "project_name": "Project", "apartment_uuid": "u1",
        "tower": "T1", "floor": "11", "apartment_code": "11", "apartment_type": "2.5BHK",
        "page_number": 7, "layout_image_path": "/tmp/layout.jpg",
        "extracted_text": json.dumps({"apartment": {"rooms": [{
            "room_id": "room-1", "name": "Kitchen", "room_type": "Kitchen",
            "direction": "South-East", "zone": "South-East", "confidence": 0.9,
            "bbox": {"x": 0.1, "y": 0.2, "width": 0.3, "height": 0.4},
            "centre": {"x": 0.25, "y": 0.4}, "label_text": "KITCHEN"
        }]}})
    }]
    text = room_inventory_csv_bytes(rows).decode("utf-8-sig")
    assert "Room Name" in text
    assert "Kitchen" in text
    assert "South-East" in text
    assert "BBox Width" in text
