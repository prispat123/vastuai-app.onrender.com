import json
import pandas as pd
from io import BytesIO

from services.snapshots import inventory_csv_bytes


def test_csv_contains_direction_columns_and_values():
    payload = {
        "classification": {"page_type": "Single Apartment"},
        "apartment": {
            "north_direction": "North",
            "entrance_direction": "East",
            "rooms": [
                {"name": "Kitchen", "direction": "South-East", "confidence": 0.92},
                {"name": "Master Bedroom", "direction": "South-West", "confidence": 0.88},
            ],
            "confidence": 0.91,
            "notes": "Good zoning",
        },
    }
    rows = [{
        "builder_name": "Builder A", "project_name": "Project A", "tower": "T1",
        "floor": "11", "apartment_code": "1101", "apartment_type": "2.5BHK",
        "review_status": "Ready", "original_name": "plans.pdf", "page_number": 7,
        "extracted_text": json.dumps(payload),
    }]
    frame = pd.read_csv(BytesIO(inventory_csv_bytes(rows)))
    assert frame.loc[0, "North Direction"] == "North"
    assert frame.loc[0, "Entrance Direction"] == "East"
    room_map = json.loads(frame.loc[0, "Room Directions"])
    assert room_map["Kitchen"] == "South-East"
    assert "Vastu JSON" in frame.columns
