from pathlib import Path


def test_navigation_is_staged_instead_of_mutating_instantiated_widget():
    source = (Path(__file__).parents[1] / "app.py").read_text()
    assert "pending_section_key=f'{section_key}__pending'" in source
    assert "pending_section=st.session_state.pop(pending_section_key,None)" in source
    for target in ("Room Directions", "Vastu Analysis & Reports", "Page Review"):
        assert f"st.session_state[pending_section_key]='{target}'" in source
    # Only initial/default setup may write the widget key directly.
    assert source.count("st.session_state[section_key]=") == 2
