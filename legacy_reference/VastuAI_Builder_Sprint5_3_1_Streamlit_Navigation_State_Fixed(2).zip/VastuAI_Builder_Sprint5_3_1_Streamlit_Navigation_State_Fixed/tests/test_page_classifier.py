import json
from pathlib import Path

import pytest

from services.gpt_vision import _extract_json, classify_page


def test_extract_json_from_fence():
    data = _extract_json('```json\n{"page_type":"Single Apartment","house_count":1}\n```')
    assert data["house_count"] == 1


def test_classifier_enforces_single_home(monkeypatch, tmp_path: Path):
    image = tmp_path / "page.jpg"
    image.write_bytes(b"fake")

    def fake_request(**kwargs):
        return {
            "page_type": "Single Apartment",
            "house_count": 2,
            "analyse": True,
            "confidence": 0.99,
            "reason": "Two homes",
        }, json.dumps({})

    monkeypatch.setattr("services.gpt_vision._request_json", fake_request)
    result, _ = classify_page(image)
    assert result["analyse"] is False
    assert result["house_count"] == 2


def test_unknown_type_is_normalized(monkeypatch, tmp_path: Path):
    image = tmp_path / "page.jpg"
    image.write_bytes(b"fake")
    monkeypatch.setattr(
        "services.gpt_vision._request_json",
        lambda **kwargs: ({"page_type": "Random Drawing", "house_count": 0, "analyse": False}, "{}"),
    )
    result, _ = classify_page(image)
    assert result["page_type"] == "Unknown"
