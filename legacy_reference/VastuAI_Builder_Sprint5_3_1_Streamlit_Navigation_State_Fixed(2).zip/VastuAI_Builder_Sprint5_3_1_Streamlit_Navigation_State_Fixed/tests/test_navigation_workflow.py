from pathlib import Path


def test_project_navigation_is_stateful_and_not_streamlit_tabs():
    source = (Path(__file__).resolve().parents[1] / "app.py").read_text()
    assert "section_key=f'project_section_{pid}'" in source
    assert "st.radio(" in source
    assert "st.tabs(['Overview'" not in source


def test_manual_review_has_one_clear_completion_action():
    source = (Path(__file__).resolve().parents[1] / "app.py").read_text()
    assert "Save room corrections & run Vastu analysis" in source
    assert "Save room corrections'" not in source
    assert "st.session_state[pending_section_key]='Vastu Analysis & Reports'" in source


def test_orientation_recalculation_remains_in_room_review():
    source = (Path(__file__).resolve().parents[1] / "app.py").read_text()
    assert "st.session_state[pending_section_key]='Room Directions'" in source
    assert "North and entrance saved. Room directions were recalculated" in source
