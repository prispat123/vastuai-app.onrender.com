from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
import streamlit as st
from services import db
from services.exports import inventory_dataframe, to_excel_bytes
from services.pdf_ingestion import process_pdf_bytes, sha256_bytes
from services.gpt_vision import VisionSettings, api_key_available, analyse_single_apartment
from services.snapshots import project_json_bytes, inventory_csv_bytes, room_inventory_csv_bytes, parse_project_json
from services.storage import data_root, uploads_root
from shared_analysis.engine import analyse_layout, apply_manual_overrides, apply_room_overrides, run_vastu_analysis
from services.reports import apartment_report_pdf, project_report_pdf

ROOT=Path(__file__).resolve().parent
UPLOAD_ROOT=uploads_root()
st.set_page_config(page_title='VastuAI Builder',page_icon='🏗️',layout='wide')
db.init_db()

if 'page' not in st.session_state: st.session_state.page='Projects'
def go(page,pid=None):
    st.session_state.page=page
    if pid is not None: st.session_state.project_id=pid

def reset():
    st.session_state.page='Projects'; st.session_state.pop('project_id',None)

with st.sidebar:
    st.title('🏗️ VastuAI Builder')
    st.caption('Project Vastu Compliance Platform')
    if st.button('Projects',use_container_width=True): reset(); st.rerun()
    if st.button('New Project',use_container_width=True): go('New Project'); st.rerun()
    st.divider()
    if api_key_available():
        st.success('OpenAI API key detected.')
    else:
        st.error('OPENAI_API_KEY is missing. Copy .env.example to .env and add your key.')
    st.info('GPT-5 Vision adds only pages containing exactly one complete apartment.')
    st.caption(f'Persistent data: {data_root()}')

def projects_page():
    a,b=st.columns([4,1]); a.title('Projects')
    notice=st.session_state.pop('projects_notice',None)
    if notice:
        level,message=notice
        getattr(st,level,st.info)(message)
    if b.button('＋ New Project',type='primary',use_container_width=True): go('New Project'); st.rerun()
    with st.expander('Import previously extracted project data'):
        st.caption('Import a VastuAI project JSON snapshot. This restores builder, project, page decisions, apartments and all extracted Vastu JSON without any API calls.')
        snapshot_file=st.file_uploader('Project JSON snapshot',type=['json'],key='project_snapshot_import')
        if snapshot_file and st.button('Import project snapshot',type='primary'):
            try:
                imported_pid=db.import_project_snapshot(parse_project_json(snapshot_file.getvalue()))
                go('Project',imported_pid); st.success('Project restored without calling the API.'); st.rerun()
            except Exception as exc:
                st.error(f'Import failed: {exc}')
    rows=db.list_projects()
    if not rows: st.info('No projects yet.'); return
    for p in rows:
        with st.container(border=True):
            c=st.columns([3,2,1,1,1,1])
            c[0].subheader(p['project_name']); c[0].caption(f"{p['builder_name']} · {p['location'] or 'Location not set'}")
            c[1].write(f"**Status:** {p['project_status']}"); c[2].metric('PDFs',p['document_count']); c[3].metric('Single units',p['apartment_count'])
            if c[4].button('Open',key=f"o{p['id']}",use_container_width=True): go('Project',p['id']); st.rerun()
            if c[5].button('Delete',key=f"delete_start_{p['id']}",use_container_width=True):
                st.session_state.delete_project_id=int(p['id'])
                st.rerun()

            if st.session_state.get('delete_project_id') == int(p['id']):
                st.error('Permanent deletion removes database records, uploaded PDFs, rendered pages, AI cache, apartment images and saved JSON assets.')
                st.download_button(
                    'Download JSON backup before deleting',
                    project_json_bytes(int(p['id'])),
                    file_name=f"{p['project_name']}_before_delete.json",
                    mime='application/json',
                    key=f"delete_backup_{p['id']}",
                )
                confirm_name=st.text_input(
                    f"Type the project name exactly to confirm: {p['project_name']}",
                    key=f"delete_name_{p['id']}",
                )
                acknowledge=st.checkbox(
                    'I understand this project and its stored assets cannot be recovered unless I have exported a backup.',
                    key=f"delete_ack_{p['id']}",
                )
                d1,d2=st.columns(2)
                if d1.button('Cancel',key=f"delete_cancel_{p['id']}",use_container_width=True):
                    st.session_state.pop('delete_project_id',None)
                    st.rerun()
                confirmed=confirm_name.strip()==str(p['project_name']).strip() and acknowledge
                if d2.button('Permanently delete project',type='primary',disabled=not confirmed,key=f"delete_confirm_{p['id']}",use_container_width=True):
                    try:
                        result=db.delete_project_permanently(int(p['id']))
                        st.session_state.pop('delete_project_id',None)
                        st.session_state.projects_notice=('success',f"Deleted {result['project_name']} and its persistent project files.")
                        st.rerun()
                    except Exception as exc:
                        st.error(f'Delete failed: {exc}')

def new_project_page():
    st.header('Create Project')
    with st.form('new'):
        c1,c2=st.columns(2)
        name=c1.text_input('Project name *'); builder=c2.text_input('Builder / developer *')
        loc=c1.text_input('Location'); arch=c2.text_input('Architect')
        status=c1.selectbox('Status',['Planning','Design Review','Pre-Construction','Construction','Completed'])
        notes=st.text_area('Notes'); save=st.form_submit_button('Create Project',type='primary')
    if save:
        if not name.strip() or not builder.strip(): st.error('Project name and builder are required.')
        else: go('Project',db.create_project(name,builder,loc,arch,status,notes)); st.rerun()

def project_page():
    pid=st.session_state.get('project_id'); p=db.get_project(pid) if pid else None
    if not p: reset(); st.rerun()
    st.title(p['project_name'])
    st.caption(f"{p['builder_name']} · {p['location'] or 'Location not set'}")
    sections=['Overview','Apartment Layouts','Room Directions','Vastu Analysis & Reports','Upload & Classify','Page Review','Single-Apartment Inventory','Documents','Data Backup']
    section_key=f'project_section_{pid}'
    # Navigation requested by a button is staged under a separate key. Streamlit
    # does not allow changing a widget's own session-state key after that widget
    # has been instantiated during the same run. Apply the staged destination
    # before creating the radio widget on the next rerun.
    pending_section_key=f'{section_key}__pending'
    pending_section=st.session_state.pop(pending_section_key,None)
    if pending_section in sections:
        st.session_state[section_key]=pending_section
    if section_key not in st.session_state or st.session_state[section_key] not in sections:
        st.session_state[section_key]='Overview'
    section=st.radio(
        'Project workspace',
        sections,
        horizontal=True,
        key=section_key,
        label_visibility='collapsed',
    )
    st.divider()
    notice=st.session_state.pop(f'action_notice_{pid}',None)
    if notice:
        level,message=notice
        getattr(st,level,st.info)(message)
    db.ensure_apartment_assets(pid)
    inventory=db.list_inventory(pid); docs=db.list_documents(pid); reviews=db.list_page_reviews(pid)

    if section == 'Overview':
        single=len(inventory); total=len(reviews); multi=sum(r['page_type']=='Multi-Apartment Floor' for r in reviews); skipped=sum(not bool(r['analyse']) for r in reviews)
        c=st.columns(4); c[0].metric('PDF pages',total); c[1].metric('Single apartments',single); c[2].metric('Multi-apartment pages',multi); c[3].metric('Skipped pages',skipped)
        st.success('Analysis inventory contains only pages confidently identified as one complete apartment layout.')

    if section == 'Apartment Layouts':
        st.header('Apartment Layouts')
        st.caption('Saved apartment layouts and GPT extraction are restored directly from permanent project storage. Opening this page does not make API calls.')
        if not inventory:
            st.info('No saved apartment layouts yet.')
        else:
            search=st.text_input('Search tower, floor, apartment or type',key=f'layout_search_{pid}').strip().lower()
            visible=[]
            for row in inventory:
                text=' '.join(str(row[k] or '') for k in ('tower','floor','apartment_code','apartment_type')).lower()
                if not search or search in text: visible.append(row)
            columns=st.columns(3)
            for index,row in enumerate(visible):
                with columns[index % 3]:
                    title=f"{row['tower'] or 'Tower ?'} · {row['apartment_code'] or 'Apartment ?'}"
                    st.markdown(f'**{title}**')
                    st.caption(f"Floor {row['floor'] or '?'} · {row['apartment_type'] or 'Type not set'} · Page {row['page_number'] or '?'}")
                    image_path=Path(row['layout_image_path'] or row['page_image_path'] or '')
                    if image_path.exists():
                        st.image(str(image_path),use_container_width=True)
                    else:
                        st.warning('Saved layout image is missing. Use Repair Assets in Documents.')
                    payload={}
                    try: payload=json.loads(row['extracted_text'] or '{}')
                    except Exception: payload={}
                    apartment=payload.get('apartment',payload) if isinstance(payload,dict) else {}
                    if isinstance(apartment,dict):
                        st.write(f"North: **{apartment.get('north_direction','Unknown')}**")
                        st.write(f"Entrance: **{apartment.get('entrance_direction','Unknown')}**")
                    with st.expander('Saved extraction JSON'):
                        st.json(payload)

    if section == 'Room Directions':
        st.header('Room Directions & Manual Review')
        st.caption('Room names, directions, confidence and normalized layout coordinates are saved in the apartment JSON and restored without API calls in future builds.')
        room_rows=[]
        missing=[]
        for row in inventory:
            payload={}
            try: payload=json.loads(row['extracted_text'] or '{}')
            except Exception: payload={}
            apartment=payload.get('apartment',payload) if isinstance(payload,dict) else {}
            rooms=apartment.get('rooms',[]) if isinstance(apartment,dict) and isinstance(apartment.get('rooms',[]),list) else []
            if not rooms:
                missing.append(row)
            for room in rooms:
                if not isinstance(room,dict): continue
                bbox=room.get('bbox',{}) if isinstance(room.get('bbox'),dict) else {}
                room_rows.append({
                    'Tower':row['tower'],'Floor':row['floor'],'Apartment':row['apartment_code'],
                    'Room':room.get('name',''),'Type':room.get('room_type',''),
                    'Direction':room.get('direction','Unknown'),'Zone':room.get('zone',room.get('direction','Unknown')),
                    'Confidence':room.get('confidence',0),'X':bbox.get('x',''),'Y':bbox.get('y',''),
                    'Width':bbox.get('width',''),'Height':bbox.get('height','')
                })
        c1,c2,c3=st.columns(3)
        c1.metric('Apartments',len(inventory)); c2.metric('Rooms extracted',len(room_rows)); c3.metric('Apartments missing rooms',len(missing))
        if room_rows:
            st.dataframe(pd.DataFrame(room_rows),use_container_width=True,hide_index=True)
            st.download_button('Download room-level CSV',room_inventory_csv_bytes(inventory),file_name=f"{p['project_name']}_room_directions.csv",mime='text/csv')
        else:
            st.info('No room-level extraction has been saved yet.')
        st.divider()
        st.subheader('Review one apartment')
        st.caption('Select an apartment to review its saved layout, confirm North and entrance, then edit every room direction on the same screen before running Vastu analysis.')
        if inventory:
            edit_labels=[f"{r['tower'] or 'Tower ?'} · {r['apartment_code'] or 'Apartment ?'} · Page {r['page_number'] or '?'}" for r in inventory]
            edit_label=st.selectbox('Apartment to review',edit_labels,key=f'manual_review_{pid}')
            edit_row=inventory[edit_labels.index(edit_label)]
            try: edit_payload=json.loads(edit_row['extracted_text'] or '{}')
            except Exception: edit_payload={}
            edit_apartment=edit_payload.get('apartment',edit_payload) if isinstance(edit_payload,dict) else {}
            if not isinstance(edit_apartment,dict): edit_apartment={}

            image_path=Path(edit_row['layout_image_path'] or edit_row['page_image_path'] or '')
            view_col, control_col=st.columns([1.35,1],gap='large')
            with view_col:
                st.markdown('#### Apartment layout')
                if image_path.exists():
                    st.image(str(image_path),use_container_width=True,caption=edit_label)
                    st.caption('Use the full-size browser image viewer or zoom the page to inspect room labels and the entrance while editing.')
                else:
                    st.warning('Saved layout image is missing. Use Repair Assets in Documents.')
            with control_col:
                st.markdown('#### 1. Confirm orientation and entrance')
                current_north=edit_apartment.get('north_page_position') or ''
                current_entrance=edit_apartment.get('entrance_direction','Unknown')
                north_options=['Not changed','Top','Right','Bottom','Left']
                north_choice=st.selectbox('North points to this side of the page',north_options,index=(north_options.index(current_north) if current_north in north_options else 0),key=f'north_edit_{edit_row["id"]}')
                st.caption(f"Current source: {edit_apartment.get('north_source','unknown')} · confidence: {edit_apartment.get('north_confidence',0)}")
                dir_options=['Unknown','North','North-East','East','South-East','South','South-West','West','North-West','Centre']
                entrance_choice=st.selectbox('Entrance direction',dir_options,index=(dir_options.index(current_entrance) if current_entrance in dir_options else 0),key=f'entrance_edit_{edit_row["id"]}')
                st.caption(f"Current source: {edit_apartment.get('entrance_source','AI')} · value: {current_entrance}")
                if st.button('Recalculate room directions',use_container_width=True,key=f'recalc_manual_{edit_row["id"]}'):
                    page_north=None if north_choice=='Not changed' else north_choice
                    entrance=None if entrance_choice==current_entrance else entrance_choice
                    if not page_north and entrance is None:
                        st.info('Select a North side or change the entrance first.')
                    else:
                        corrected=apply_manual_overrides(edit_apartment,page_north=page_north,entrance_direction=entrance)
                        if isinstance(edit_payload,dict) and 'apartment' in edit_payload: edit_payload['apartment']=corrected
                        else: edit_payload=corrected
                        db.update_apartment_extraction(pid,edit_row['id'],edit_payload)
                        st.session_state[pending_section_key]='Room Directions'
                        st.session_state[f'action_notice_{pid}']=('success','North and entrance saved. Room directions were recalculated; review and correct the room table below.')
                        st.rerun()

            st.markdown('#### 2. Review and edit room directions')
            st.caption('Edit the Direction column directly. You may also add a missed room or remove an incorrect row. Saved edits are marked Manual and used immediately by the shared Vastu engine.')
            room_editor_rows=[]
            for room in edit_apartment.get('rooms',[]):
                if not isinstance(room,dict): continue
                room_editor_rows.append({
                    'Room':room.get('name',''),
                    'Type':room.get('room_type',''),
                    'Direction':room.get('direction','Unknown'),
                    'Source':room.get('direction_source','AI'),
                })
            editor_df=pd.DataFrame(room_editor_rows,columns=['Room','Type','Direction','Source'])
            edited_rooms=st.data_editor(
                editor_df,
                num_rows='dynamic',
                use_container_width=True,
                hide_index=True,
                key=f'room_editor_{edit_row["id"]}',
                column_config={
                    'Room':st.column_config.TextColumn('Room',required=True),
                    'Type':st.column_config.TextColumn('Type'),
                    'Direction':st.column_config.SelectboxColumn('Direction',options=dir_options,required=True),
                    'Source':st.column_config.TextColumn('Source',disabled=True),
                },
            )
            st.markdown('#### 3. Analyse and continue')
            if st.button('Save room corrections & run Vastu analysis',type='primary',use_container_width=True,key=f'analyse_rooms_{edit_row["id"]}'):
                corrected=apply_room_overrides(edit_apartment,edited_rooms.to_dict('records'))
                corrected['vastu_result']=run_vastu_analysis(corrected)
                if isinstance(edit_payload,dict) and 'apartment' in edit_payload: edit_payload['apartment']=corrected
                else: edit_payload=corrected
                db.update_apartment_extraction(pid,edit_row['id'],edit_payload)
                st.session_state[pending_section_key]='Vastu Analysis & Reports'
                st.session_state[f'action_notice_{pid}']=('success','Manual review completed. Vastu analysis is updated; review the results and generate reports below.')
                st.rerun()

            vr=edit_apartment.get('vastu_result') if isinstance(edit_apartment.get('vastu_result'),dict) else {}
            if vr:
                st.markdown('#### Latest Vastu result')
                mc=st.columns(4)
                mc[0].metric('Score',f"{vr.get('score','—')}/10")
                mc[1].metric('Grade',vr.get('grade','—'))
                mc[2].metric('Status',vr.get('status','—'))
                mc[3].metric('Coverage',f"{vr.get('coverage','—')}%")
                st.info('Open **Vastu Analysis & Reports** to review the complete assessment and download apartment or project reports.')
            else:
                st.warning('No Vastu result yet. Confirm North and entrance, review room directions, then click Save rooms & run Vastu analysis.')

        if missing:
            st.warning(f'{len(missing)} apartment(s) were analysed by an older build and do not yet contain room-level data.')
            if st.button('Extract rooms for missing apartments',type='primary',disabled=not api_key_available(),use_container_width=True):
                progress=st.progress(0,text='Preparing room extraction...')
                completed=0
                for idx,row in enumerate(missing,start=1):
                    image_path=Path(row['layout_image_path'] or row['page_image_path'] or '')
                    if not image_path.exists():
                        continue
                    progress.progress(idx/max(len(missing),1),text=f"Extracting rooms: {row['tower']} {row['apartment_code']}")
                    detail,raw=analyse_layout(image_path,VisionSettings())
                    try: payload=json.loads(row['extracted_text'] or '{}')
                    except Exception: payload={}
                    if not isinstance(payload,dict): payload={}
                    payload['apartment']=detail
                    payload['raw']=raw
                    db.update_apartment_extraction(pid,row['id'],payload)
                    completed+=1
                progress.empty()
                st.session_state[pending_section_key]='Room Directions'
                st.session_state[f'action_notice_{pid}']=('success',f'Room extraction saved for {completed} apartment(s). Select an apartment below to review and correct it.')
                st.rerun()
        else:
            st.success('All analysed apartments already have saved room information. Opening this project makes no API calls.')

    if section == 'Vastu Analysis & Reports':
        st.header('Vastu Analysis & Reports')
        st.caption('Runs the same deterministic weighted Vastu rules for every apartment using the saved North, entrance and room directions. This step does not call OpenAI.')
        analysed=[]; eligible=[]; unavailable=[]
        for row in inventory:
            try: payload=json.loads(row['extracted_text'] or '{}')
            except Exception: payload={}
            apartment=payload.get('apartment',payload) if isinstance(payload,dict) else {}
            if not isinstance(apartment,dict): apartment={}
            result=apartment.get('vastu_result') if isinstance(apartment.get('vastu_result'),dict) else {}
            if result: analysed.append((row,apartment,result))
            elif apartment.get('north_direction','Unknown')!='Unknown' and (apartment.get('rooms') or apartment.get('entrance_direction','Unknown')!='Unknown'):
                eligible.append((row,payload,apartment))
            else: unavailable.append(row)

        c1,c2,c3,c4=st.columns(4)
        c1.metric('Apartments',len(inventory)); c2.metric('Analysed',len(analysed)); c3.metric('Ready to analyse',len(eligible)); c4.metric('Needs direction review',len(unavailable))
        if eligible:
            if st.button('Analyse all eligible apartments',type='primary',use_container_width=True,key=f'analyse_all_{pid}'):
                progress=st.progress(0,text='Running Vastu rules...')
                completed=0
                for idx,(row,payload,apartment) in enumerate(eligible,start=1):
                    result=run_vastu_analysis(apartment)
                    if result:
                        apartment['vastu_result']=result
                        if isinstance(payload,dict) and 'apartment' in payload: payload['apartment']=apartment
                        else: payload=apartment
                        db.update_apartment_extraction(pid,row['id'],payload)
                        completed+=1
                    progress.progress(idx/max(len(eligible),1),text=f"Analysing {row['tower']} {row['apartment_code']}")
                progress.empty()
                st.session_state[pending_section_key]='Vastu Analysis & Reports'
                st.session_state[f'action_notice_{pid}']=('success',f'Vastu analysis saved for {completed} apartment(s). Results and reports are ready below; no Vision API calls were made.')
                st.rerun()
        if unavailable:
            st.warning(f"{len(unavailable)} apartment(s) cannot be scored until North and at least one supported room/entrance direction are confirmed.")

        if analysed:
            scores=[float(x[2].get('score',0)) for x in analysed]
            a,b,c=st.columns(3); a.metric('Average score',f"{sum(scores)/len(scores):.1f}/10"); b.metric('Highest',f"{max(scores):.1f}/10"); c.metric('A / A+',sum(str(x[2].get('grade','')).startswith('A') for x in analysed))
            score_rows=[]
            for row,apartment,result in analysed:
                score_rows.append({'Tower':row['tower'],'Floor':row['floor'],'Apartment':row['apartment_code'],'Type':row['apartment_type'],'Score':result.get('score'),'Percentage':result.get('percentage'),'Grade':result.get('grade'),'Status':result.get('status'),'Coverage %':result.get('coverage'),'Confidence':result.get('confidence')})
            st.dataframe(pd.DataFrame(score_rows),use_container_width=True,hide_index=True)
            st.download_button('Download complete project Vastu PDF',project_report_pdf(p,inventory),file_name=f"{p['project_name']}_Vastu_Report.pdf",mime='application/pdf',use_container_width=True)
            st.divider()
            labels=[f"{r['tower'] or 'Tower ?'} · {r['apartment_code'] or 'Apartment ?'}" for r,_,_ in analysed]
            selected_label=st.selectbox('Apartment detail',labels,key=f'analysis_select_{pid}')
            row,apartment,result=analysed[labels.index(selected_label)]
            m1,m2,m3,m4=st.columns(4); m1.metric('Score',f"{result.get('score')}/10"); m2.metric('Grade',result.get('grade')); m3.metric('Status',result.get('status')); m4.metric('Confidence',result.get('confidence'))
            image_path=Path(row['layout_image_path'] or row['page_image_path'] or '')
            left,right=st.columns([1,1.3])
            with left:
                if image_path.exists(): st.image(str(image_path),use_container_width=True)
                st.write(f"North: **{apartment.get('north_direction','Unknown')}**")
                st.write(f"Entrance: **{apartment.get('entrance_direction','Unknown')}**")
                st.download_button('Download apartment PDF report',apartment_report_pdf(p,row),file_name=f"{p['project_name']}_{row['tower']}_{row['apartment_code']}_Vastu.pdf",mime='application/pdf',use_container_width=True,key=f"ap_pdf_{row['id']}")
            with right:
                details=result.get('details',[])
                if details:
                    detail_df=pd.DataFrame([{'Area':d.get('area'),'Direction':d.get('direction'),'Score':d.get('score'),'Status':d.get('status'),'Severity':d.get('severity'),'Rationale':d.get('rationale'),'Recommendation':d.get('non_structural_remedy') or d.get('structural_remedy')} for d in details])
                    st.dataframe(detail_df,use_container_width=True,hide_index=True)
                if result.get('strengths'):
                    st.success('Strengths: ' + ' '.join(result['strengths']))
                if result.get('cautions'):
                    st.warning('Concerns: ' + ' '.join(result['cautions']))
                with st.expander('Full saved Vastu result'): st.json(result)
        else:
            st.info('No apartment currently has a saved Vastu analysis. Use Analyse all eligible apartments above.')

    if section == 'Upload & Classify':
        st.header('Upload & Classify')
        st.caption('GPT-5 Vision classifies every page. Pages with more than one home are skipped automatically; only single-apartment pages receive detailed extraction.')
        with st.expander('Vision settings'):
            c1,c2=st.columns(2)
            classifier_model=c1.text_input('Classifier model',value=VisionSettings().classifier_model)
            detail_model=c2.text_input('Detailed vision model',value=VisionSettings().detail_model)
            st.caption('The classifier uses low-detail images. Detailed high-resolution analysis runs only for eligible single-apartment pages.')
        ups=st.file_uploader('PDF files',type=['pdf'],accept_multiple_files=True,key=f'pdf_upload_{pid}')
        process_clicked=st.button(
            'Process PDFs',
            type='primary',
            disabled=(not api_key_available() or not ups),
            key=f'process_pdfs_{pid}',
            use_container_width=True,
        )
        if not api_key_available():
            st.warning('Add OPENAI_API_KEY to the .env file beside app.py, then restart Streamlit.')
        elif not ups:
            st.caption('Choose one or more PDFs; the Process PDFs button will then become active.')
        if process_clicked:
            project_dir=UPLOAD_ROOT/f'project_{pid}'; project_dir.mkdir(parents=True,exist_ok=True)
            processed_docs=0; added_units=0; failures=[]
            status=st.status('Processing selected PDF files…',expanded=True)
            for u in ups:
                data=u.getvalue(); h=sha256_bytes(data)
                if not data:
                    failures.append(f'{u.name}: uploaded file is empty.')
                    status.write(f'❌ {u.name}: empty file')
                    continue
                if db.document_exists(pid,h):
                    status.write(f'ℹ️ {u.name}: already exists; use Documents → Rebuild to reprocess it.')
                    continue
                safe=Path(u.name).name; ddir=project_dir/f'{Path(safe).stem}_{h[:10]}'; ddir.mkdir(parents=True,exist_ok=True)
                pdf_path=ddir/safe; pdf_path.write_bytes(data)
                progress=st.progress(0,text=f'Preparing {safe}…')
                def update_progress(page_no,total,message):
                    progress.progress(min(page_no/max(total,1),1.0),text=message)
                settings=VisionSettings(classifier_model=classifier_model.strip(),detail_model=detail_model.strip())
                try:
                    status.write(f'▶️ Processing {safe}')
                    pages,rows,page_rows=process_pdf_bytes(data,ddir/'pages',safe,settings=settings,progress_callback=update_progress)
                    docid=db.add_document(pid,safe,str(pdf_path),h,pages)
                    for r in rows: r.update(project_id=pid,document_id=docid)
                    for r in page_rows: r.update(project_id=pid,document_id=docid)
                    db.add_inventory_rows(rows); db.add_page_reviews(page_rows)
                    processed_docs+=1; added_units+=len(rows)
                    status.write(f'✅ {safe}: {pages} pages scanned; {len(rows)} single-apartment page(s) saved.')
                except Exception as exc:
                    failures.append(f'{safe}: {exc}')
                    status.write(f'❌ {safe}: {exc}')
                finally:
                    progress.empty()
            if failures:
                status.update(label=f'Completed with {len(failures)} error(s)',state='error',expanded=True)
                st.error('\n'.join(failures))
            else:
                status.update(label='PDF processing completed',state='complete',expanded=False)
            if processed_docs:
                st.session_state[pending_section_key]='Page Review'
                st.session_state[f'action_notice_{pid}']=('success',f'Processed {processed_docs} PDF(s) and saved {added_units} single-apartment layout(s). Review the page decisions below.')
                st.rerun()

    if section == 'Page Review':
        st.header('Page Review')
        st.caption('This is a transparent audit of what was included or skipped.')
        if not reviews: st.info('No classified pages yet.')
        else:
            rdf=pd.DataFrame([dict(r) for r in reviews])
            cols=['original_name','page_number','page_type','house_count','analyse','confidence','reason']
            for col in cols:
                if col not in rdf: rdf[col]=''
            show=rdf[cols].rename(columns={'original_name':'PDF','page_number':'Page','page_type':'Page Type','house_count':'Homes','analyse':'Analyse','confidence':'Confidence','reason':'Reason'})
            st.dataframe(show,use_container_width=True,hide_index=True)
            st.caption('Review AI decisions before analysis. A page is eligible only when Page Type is Single Apartment and Homes equals 1.')

    if section == 'Single-Apartment Inventory':
        st.header('Single-Apartment Inventory')
        with st.expander('Import apartment CSV'):
            st.caption('Use this for apartment rows exported from an earlier build. North, entrance and every room direction are preserved in dedicated columns and in the full Vastu JSON; no API calls are made.')
            csv_file=st.file_uploader('CSV file',type=['csv'],key=f'csv_import_{pid}')
            if csv_file and st.button('Import CSV rows',key=f'import_csv_{pid}'):
                try:
                    imported_df=pd.read_csv(csv_file)
                    count=db.import_inventory_csv(pid,imported_df.fillna('').to_dict('records'))
                    st.success(f'Imported {count} apartment row(s) without API calls.'); st.rerun()
                except Exception as exc:
                    st.error(f'CSV import failed: {exc}')
        if not inventory: st.info('No eligible single-apartment pages found.')
        else:
            edit=pd.DataFrame([dict(r) for r in inventory])[['id','tower','floor','apartment_code','apartment_type','review_status','original_name','page_number']]
            edit.insert(0,'delete',False)
            edited=st.data_editor(edit,use_container_width=True,hide_index=True,disabled=['id','original_name','page_number'],column_config={
                'delete':st.column_config.CheckboxColumn('Delete'),
                'apartment_type':st.column_config.TextColumn('Type'),
                'review_status':st.column_config.SelectboxColumn('Status',options=['Needs Review','Ready','Excluded'])
            },key=f'inv{pid}')
            c1,c2,c3,c4=st.columns([1,1,1,2])
            if c1.button('Save edits',type='primary',use_container_width=True):
                db.replace_inventory(pid,edited.drop(columns=['delete']).to_dict('records')); st.success('Saved.'); st.rerun()
            if c2.button('Delete selected',use_container_width=True):
                ids=edited.loc[edited['delete']==True,'id'].tolist()
                if ids: db.delete_inventory_rows(pid,ids); st.success(f'Deleted {len(ids)} row(s).'); st.rerun()
                else: st.warning('Select rows using the Delete checkbox.')
            c3.download_button('CSV + Direction Data',inventory_csv_bytes(inventory),file_name=f"{p['project_name']}_single_units_with_vastu.csv",mime='text/csv',use_container_width=True)
            c4.download_button('Excel',to_excel_bytes(inventory_dataframe(inventory)),file_name=f"{p['project_name']}_single_units.xlsx",mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

    if section == 'Documents':
        st.header('Documents')
        if docs:
            st.dataframe(pd.DataFrame([dict(r) for r in docs])[['original_name','page_count','uploaded_at']],use_container_width=True,hide_index=True)
            c_repair,c_rebuild=st.columns(2)
            if c_repair.button('Repair persistent apartment assets',use_container_width=True,key=f'repair_assets_{pid}'):
                try:
                    repaired=db.ensure_apartment_assets(pid)
                    st.session_state[f'action_notice_{pid}']=('success',f'Repaired {repaired} apartment asset record(s). No API calls were made.')
                    st.rerun()
                except Exception as exc:
                    st.error(f'Asset repair failed: {exc}')
            rebuild_disabled=not api_key_available()
            rebuild_clicked=c_rebuild.button(
                'Rebuild classification and inventory',
                type='primary',
                use_container_width=True,
                disabled=rebuild_disabled,
                key=f'rebuild_inventory_{pid}',
            )
            if rebuild_disabled:
                st.warning('Rebuild requires OPENAI_API_KEY. Cached responses are reused where available, but the key is required for uncached pages.')
            if rebuild_clicked:
                total_units=0; rebuilt_docs=0; failures=[]
                status=st.status('Rebuilding document classification and apartment inventory…',expanded=True)
                overall=st.progress(0,text='Starting rebuild…')
                for doc_index,doc in enumerate(docs,start=1):
                    path=Path(doc['stored_path'])
                    overall.progress((doc_index-1)/max(len(docs),1),text=f"Document {doc_index}/{len(docs)}: {doc['original_name']}")
                    if not path.exists():
                        msg=f"{doc['original_name']}: stored PDF is missing at {path}"
                        failures.append(msg); status.write(f'❌ {msg}'); continue
                    page_progress=st.progress(0,text=f"Preparing {doc['original_name']}…")
                    def update_progress(page_no,total,message):
                        page_progress.progress(min(page_no/max(total,1),1.0),text=message)
                    try:
                        # Process first. Existing records are deleted only after successful extraction,
                        # preventing a failed API/network call from erasing the current project data.
                        _,rows,page_rows=process_pdf_bytes(
                            path.read_bytes(),path.parent/'pages',doc['original_name'],
                            settings=VisionSettings(),progress_callback=update_progress,
                        )
                        for r in rows: r.update(project_id=pid,document_id=doc['id'])
                        for r in page_rows: r.update(project_id=pid,document_id=doc['id'])
                        db.delete_inventory_for_document(pid,doc['id'])
                        db.delete_page_reviews_for_document(pid,doc['id'])
                        db.add_inventory_rows(rows); db.add_page_reviews(page_rows)
                        rebuilt_docs+=1; total_units+=len(rows)
                        status.write(f"✅ {doc['original_name']}: {len(rows)} single-apartment page(s) saved.")
                    except Exception as exc:
                        msg=f"{doc['original_name']}: {exc}"
                        failures.append(msg); status.write(f'❌ {msg}')
                    finally:
                        page_progress.empty()
                overall.progress(1.0,text='Rebuild finished')
                overall.empty()
                if failures:
                    status.update(label=f'Rebuild completed with {len(failures)} error(s)',state='error',expanded=True)
                    st.error('\n'.join(failures))
                else:
                    status.update(label='Rebuild completed',state='complete',expanded=False)
                if rebuilt_docs:
                    st.session_state[pending_section_key]='Page Review'
                    st.session_state[f'action_notice_{pid}']=('success',f'Rebuilt {rebuilt_docs} document(s) with {total_units} single-apartment layout(s). Review the refreshed page decisions below.')
                    st.rerun()

        else: st.info('No documents uploaded.')

    if section == 'Data Backup':
        st.header('Data Backup')
        st.success('The database, uploaded PDFs and GPT vision cache are stored outside the application build folder. Installing a new build does not erase them.')
        st.code(str(data_root()), language=None)
        st.caption('Keep this folder when upgrading. You may also set VASTUAI_DATA_DIR in .env to place it on another drive or synced folder.')
        c1,c2=st.columns(2)
        c1.download_button('Download complete project JSON',project_json_bytes(pid),file_name=f"{p['project_name']}_vastuai_backup.json",mime='application/json',use_container_width=True)
        c2.download_button('Download apartment CSV + directions',inventory_csv_bytes(inventory),file_name=f"{p['project_name']}_apartments_with_vastu.csv",mime='text/csv',use_container_width=True)
        st.download_button('Download room-level CSV',room_inventory_csv_bytes(inventory),file_name=f"{p['project_name']}_room_directions.csv",mime='text/csv',use_container_width=True)
        st.markdown('**Recommended upgrade workflow**')
        st.write('1. Leave the persistent data folder in place. 2. Extract the new code build into a new folder. 3. Run it. The same projects and AI cache will appear automatically. 4. Keep a JSON snapshot as an additional backup.')

page=st.session_state.page
{'Projects':projects_page,'New Project':new_project_page,'Project':project_page}.get(page,projects_page)()
