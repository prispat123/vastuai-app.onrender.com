from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

import pandas as pd

from services import db


def _parse_vastu_payload(value: Any) -> dict:
    """Return the full saved extraction payload without losing unknown fields."""
    if isinstance(value, dict):
        return value
    if value is None:
        return {}
    text = str(value).strip()
    if not text:
        return {}
    try:
        parsed = json.loads(text)
        return parsed if isinstance(parsed, dict) else {}
    except json.JSONDecodeError:
        return {}


def _apartment_details(payload: dict) -> dict:
    apartment = payload.get("apartment", payload)
    return apartment if isinstance(apartment, dict) else {}


def _room_direction_map(details: dict) -> dict[str, str]:
    output: dict[str, str] = {}
    rooms = details.get("rooms", [])
    if not isinstance(rooms, list):
        return output
    for room in rooms:
        if not isinstance(room, dict):
            continue
        name = str(room.get("name", "")).strip()
        direction = str(room.get("direction", "Unknown")).strip() or "Unknown"
        if name:
            output[name] = direction
    return output


def project_json_bytes(project_id: int) -> bytes:
    payload = db.project_snapshot(project_id)
    payload["schema_version"] = 2
    payload["exported_at"] = datetime.now(timezone.utc).isoformat()

    # Add a directly usable structured Vastu object to each apartment record.
    # extracted_text remains in the snapshot for backward compatibility.
    for row in payload.get("inventory", []):
        vastu = _parse_vastu_payload(row.get("extracted_text"))
        row["vastu"] = vastu
        details = _apartment_details(vastu)
        row["north_direction"] = details.get("north_direction", "Unknown")
        row["entrance_direction"] = details.get("entrance_direction", "Unknown")
        row["room_directions"] = _room_direction_map(details)
        row["vastu_notes"] = details.get("notes", "")
        row["vastu_confidence"] = details.get("confidence", "")

    return json.dumps(payload, indent=2, ensure_ascii=False).encode("utf-8")


def inventory_csv_bytes(rows) -> bytes:
    data = []
    for row in rows:
        item = dict(row)
        payload = _parse_vastu_payload(item.get("extracted_text", ""))
        details = _apartment_details(payload)
        rooms = details.get("rooms", []) if isinstance(details.get("rooms", []), list) else []
        room_map = _room_direction_map(details)

        data.append({
            "Builder": item.get("builder_name", ""),
            "Project": item.get("project_name", ""),
            "Tower": item.get("tower", ""),
            "Floor": item.get("floor", ""),
            "Apartment": item.get("apartment_code", ""),
            "Type": item.get("apartment_type", ""),
            "Status": item.get("review_status", ""),
            "Source PDF": item.get("original_name", item.get("source_label", "")),
            "Page": item.get("page_number", ""),
            "North Direction": details.get("north_direction", "Unknown"),
            "Entrance Direction": details.get("entrance_direction", "Unknown"),
            "Room Directions": json.dumps(room_map, ensure_ascii=False),
            "Rooms JSON": json.dumps(rooms, ensure_ascii=False),
            "Vastu Score": (details.get("vastu_result") or {}).get("score", ""),
            "Vastu Grade": (details.get("vastu_result") or {}).get("grade", ""),
            "Vastu Status": (details.get("vastu_result") or {}).get("status", ""),
            "Vastu Confidence": details.get("confidence", ""),
            "Vastu Notes": details.get("notes", ""),
            "Vastu JSON": json.dumps(payload, ensure_ascii=False),
        })
    return pd.DataFrame(data).to_csv(index=False).encode("utf-8-sig")


def parse_project_json(data: bytes) -> dict:
    payload = json.loads(data.decode("utf-8-sig"))
    if not isinstance(payload, dict) or "project" not in payload or "inventory" not in payload:
        raise ValueError("This is not a valid VastuAI Builder project JSON file.")

    # New exports expose a structured `vastu` object. Re-create extracted_text so
    # older database builds and the current importer can use the same snapshot.
    for row in payload.get("inventory", []):
        if not row.get("extracted_text") and isinstance(row.get("vastu"), dict):
            row["extracted_text"] = json.dumps(row["vastu"], ensure_ascii=False)
    return payload


def room_inventory_csv_bytes(rows) -> bytes:
    """One row per extracted room for audit, Excel analysis and future imports."""
    data = []
    for row in rows:
        item = dict(row)
        payload = _parse_vastu_payload(item.get("extracted_text", ""))
        details = _apartment_details(payload)
        rooms = details.get("rooms", []) if isinstance(details.get("rooms"), list) else []
        for room in rooms:
            if not isinstance(room, dict):
                continue
            bbox = room.get("bbox") if isinstance(room.get("bbox"), dict) else {}
            centre = room.get("centre") if isinstance(room.get("centre"), dict) else {}
            data.append({
                "Builder": item.get("builder_name", ""),
                "Project": item.get("project_name", ""),
                "Apartment UUID": item.get("apartment_uuid", ""),
                "Tower": item.get("tower", ""),
                "Floor": item.get("floor", ""),
                "Apartment": item.get("apartment_code", ""),
                "Type": item.get("apartment_type", ""),
                "Room ID": room.get("room_id", ""),
                "Room Name": room.get("name", ""),
                "Room Type": room.get("room_type", ""),
                "Direction": room.get("direction", "Unknown"),
                "Zone": room.get("zone", room.get("direction", "Unknown")),
                "Confidence": room.get("confidence", ""),
                "BBox X": bbox.get("x", ""),
                "BBox Y": bbox.get("y", ""),
                "BBox Width": bbox.get("width", ""),
                "BBox Height": bbox.get("height", ""),
                "Centre X": centre.get("x", ""),
                "Centre Y": centre.get("y", ""),
                "Label Text": room.get("label_text", ""),
                "Source Page": item.get("page_number", ""),
                "Layout Image": item.get("layout_image_path", ""),
            })
    columns = [
        "Builder", "Project", "Apartment UUID", "Tower", "Floor", "Apartment", "Type",
        "Room ID", "Room Name", "Room Type", "Direction", "Zone", "Confidence",
        "BBox X", "BBox Y", "BBox Width", "BBox Height", "Centre X", "Centre Y",
        "Label Text", "Source Page", "Layout Image"
    ]
    return pd.DataFrame(data, columns=columns).to_csv(index=False).encode("utf-8-sig")
