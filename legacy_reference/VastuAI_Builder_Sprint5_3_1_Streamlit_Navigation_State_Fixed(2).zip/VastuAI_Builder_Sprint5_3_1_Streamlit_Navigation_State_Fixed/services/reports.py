from __future__ import annotations

import io
import json
from pathlib import Path
from typing import Any, Iterable

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Image


def _apartment_payload(row: Any) -> dict[str, Any]:
    try:
        payload = json.loads(row["extracted_text"] or "{}")
    except Exception:
        payload = {}
    apartment = payload.get("apartment", payload) if isinstance(payload, dict) else {}
    return apartment if isinstance(apartment, dict) else {}


def _styles():
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="ReportTitle", parent=styles["Title"], alignment=TA_CENTER, fontSize=20, spaceAfter=12))
    styles.add(ParagraphStyle(name="Section", parent=styles["Heading2"], fontSize=13, spaceBefore=10, spaceAfter=6))
    styles.add(ParagraphStyle(name="Small", parent=styles["BodyText"], fontSize=8, leading=10))
    return styles


def _footer(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica", 8)
    canvas.drawString(18 * mm, 12 * mm, "VastuAI Builder — traditional Vastu assessment")
    canvas.drawRightString(192 * mm, 12 * mm, f"Page {doc.page}")
    canvas.restoreState()


def apartment_report_pdf(project: Any, row: Any) -> bytes:
    return _build_pdf(project, [row], project_summary=False)


def project_report_pdf(project: Any, rows: Iterable[Any]) -> bytes:
    return _build_pdf(project, list(rows), project_summary=True)


def _build_pdf(project: Any, rows: list[Any], project_summary: bool) -> bytes:
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=18*mm, leftMargin=18*mm, topMargin=18*mm, bottomMargin=20*mm)
    styles = _styles()
    story = [Paragraph("VastuAI Builder", styles["ReportTitle"]),
             Paragraph(f"<b>{project['project_name']}</b>", styles["Heading2"]),
             Paragraph(f"Builder: {project['builder_name']} &nbsp;&nbsp; Location: {project['location'] or 'Not specified'}", styles["BodyText"]),
             Spacer(1, 8)]

    analysed = []
    for row in rows:
        ap = _apartment_payload(row)
        vr = ap.get("vastu_result") if isinstance(ap.get("vastu_result"), dict) else {}
        if vr:
            analysed.append((row, ap, vr))

    if project_summary:
        scores = [float(vr.get("score", 0)) for _, _, vr in analysed]
        avg = round(sum(scores)/len(scores), 1) if scores else 0
        summary = [["Apartments", str(len(rows))], ["Analysed", str(len(analysed))], ["Average Vastu score", f"{avg}/10" if scores else "Not available"],
                   ["A/A+ apartments", str(sum(1 for _,_,v in analysed if str(v.get('grade','')).startswith('A')))],
                   ["Needs attention", str(sum(1 for _,_,v in analysed if v.get('status') == 'Needs attention'))]]
        t = Table(summary, colWidths=[65*mm, 75*mm])
        t.setStyle(TableStyle([("BACKGROUND",(0,0),(0,-1),colors.HexColor("#E8EEF7")),("GRID",(0,0),(-1,-1),0.5,colors.grey),("FONTNAME",(0,0),(0,-1),"Helvetica-Bold"),("PADDING",(0,0),(-1,-1),6)]))
        story += [Paragraph("Project Summary", styles["Section"]), t, Spacer(1, 12)]
        table_data = [["Tower", "Floor", "Apartment", "Type", "Score", "Grade", "Status"]]
        for row, ap, vr in analysed:
            table_data.append([str(row['tower'] or ''), str(row['floor'] or ''), str(row['apartment_code'] or ''), str(row['apartment_type'] or ''), str(vr.get('score','')), str(vr.get('grade','')), str(vr.get('status',''))])
        if len(table_data) > 1:
            t = Table(table_data, repeatRows=1, colWidths=[20*mm,16*mm,24*mm,27*mm,15*mm,14*mm,34*mm])
            t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#23395D")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("GRID",(0,0),(-1,-1),0.4,colors.grey),("FONTSIZE",(0,0),(-1,-1),7),("PADDING",(0,0),(-1,-1),4)]))
            story += [Paragraph("Apartment Scorecard", styles["Section"]), t, PageBreak()]

    for index, row in enumerate(rows):
        ap = _apartment_payload(row)
        vr = ap.get("vastu_result") if isinstance(ap.get("vastu_result"), dict) else {}
        story.append(Paragraph(f"{row['tower'] or 'Tower ?'} — Apartment {row['apartment_code'] or '?'}", styles["Heading1"]))
        story.append(Paragraph(f"Floor {row['floor'] or '?'} · {row['apartment_type'] or 'Type not specified'} · Source page {row['page_number'] or '?'}", styles["BodyText"]))
        image_path = Path(row['layout_image_path'] or row['page_image_path'] or '')
        if image_path.is_file():
            try:
                img = Image(str(image_path), width=155*mm, height=100*mm, kind='proportional')
                story += [Spacer(1,6), img]
            except Exception:
                pass
        story += [Paragraph("Orientation", styles["Section"]), Paragraph(
            f"North: <b>{ap.get('north_direction','Unknown')}</b> ({ap.get('north_source','AI')}) &nbsp;&nbsp; Entrance: <b>{ap.get('entrance_direction','Unknown')}</b> ({ap.get('entrance_source','AI')}) &nbsp;&nbsp; Detection confidence: {ap.get('confidence',0)}",
            styles["BodyText"])]
        if not vr:
            story += [Paragraph("Vastu Analysis", styles["Section"]), Paragraph("Analysis is unavailable. Run Vastu Analysis after confirming North and room directions.", styles["BodyText"])]
        else:
            metrics = [["Overall score", f"{vr.get('score','')}/10"], ["Percentage", f"{vr.get('percentage','')}%"], ["Grade", str(vr.get('grade',''))], ["Status", str(vr.get('status',''))], ["Coverage", f"{vr.get('coverage','')}%"], ["Confidence", str(vr.get('confidence',''))]]
            mt = Table(metrics, colWidths=[45*mm,45*mm])
            mt.setStyle(TableStyle([("BACKGROUND",(0,0),(0,-1),colors.HexColor("#E8EEF7")),("GRID",(0,0),(-1,-1),0.5,colors.grey),("FONTNAME",(0,0),(0,-1),"Helvetica-Bold"),("PADDING",(0,0),(-1,-1),5)]))
            story += [Paragraph("Vastu Analysis", styles["Section"]), mt]
            details = vr.get("details", [])
            if details:
                td = [["Area", "Direction", "Score", "Status", "Recommendation"]]
                for d in details:
                    remedy = d.get("non_structural_remedy") or d.get("structural_remedy") or d.get("rationale", "")
                    td.append([Paragraph(str(d.get('area','')),styles['Small']), str(d.get('direction','')), str(d.get('score','')), str(d.get('status','')), Paragraph(str(remedy),styles['Small'])])
                dt = Table(td, repeatRows=1, colWidths=[31*mm,23*mm,14*mm,24*mm,68*mm])
                dt.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#23395D")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("GRID",(0,0),(-1,-1),0.4,colors.grey),("VALIGN",(0,0),(-1,-1),"TOP"),("FONTSIZE",(0,0),(-1,-1),7),("PADDING",(0,0),(-1,-1),4)]))
                story += [Paragraph("Room-by-room Assessment", styles["Section"]), dt]
            for heading, key in [("Strengths","strengths"),("Concerns","cautions")]:
                items = vr.get(key, [])
                if items:
                    story.append(Paragraph(heading, styles["Section"]))
                    for item in items: story.append(Paragraph(f"• {item}", styles["BodyText"]))
        story += [Spacer(1,8), Paragraph("Disclaimer: Vastu is a traditional belief-based assessment and is not a substitute for structural, legal, fire-safety, financial or engineering due diligence.", styles["Small"])]
        if index < len(rows)-1: story.append(PageBreak())

    doc.build(story, onFirstPage=_footer, onLaterPages=_footer)
    return buffer.getvalue()
