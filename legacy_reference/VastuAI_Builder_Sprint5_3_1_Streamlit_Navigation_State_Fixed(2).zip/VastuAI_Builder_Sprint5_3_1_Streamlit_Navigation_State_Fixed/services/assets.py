from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path
from typing import Any

from services.storage import data_root


def project_assets_root(project_id: int) -> Path:
    path = data_root() / "projects" / f"project_{int(project_id)}"
    path.mkdir(parents=True, exist_ok=True)
    return path


def apartment_asset_dir(project_id: int, apartment_uuid: str) -> Path:
    path = project_assets_root(project_id) / "apartments" / apartment_uuid
    path.mkdir(parents=True, exist_ok=True)
    return path


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def persist_apartment_assets(
    project_id: int,
    apartment_uuid: str,
    source_image_path: str | Path | None,
    extracted_payload: str | dict | None,
) -> dict[str, str]:
    """Copy an apartment layout and extraction JSON into permanent user storage.

    The returned paths are stable across application build upgrades because they
    live under VASTUAI_DATA_DIR (or ~/VastuAI_Builder_Data), not the code folder.
    """
    target_dir = apartment_asset_dir(project_id, apartment_uuid)
    layout_path = ""
    source_hash = ""

    if source_image_path:
        source = Path(source_image_path)
        if source.exists() and source.is_file():
            suffix = source.suffix.lower() if source.suffix else ".jpg"
            target = target_dir / f"layout{suffix}"
            source_hash = file_sha256(source)
            if not target.exists() or file_sha256(target) != source_hash:
                shutil.copy2(source, target)
            layout_path = str(target.resolve())

    analysis_path = target_dir / "analysis.json"
    payload: Any = extracted_payload or {}
    if isinstance(payload, str):
        try:
            payload = json.loads(payload) if payload.strip() else {}
        except json.JSONDecodeError:
            payload = {"raw": payload}
    analysis_path.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    return {
        "layout_image_path": layout_path,
        "analysis_json_path": str(analysis_path.resolve()),
        "source_image_hash": source_hash,
    }


def remove_apartment_assets(project_id: int, apartment_uuid: str) -> None:
    path = apartment_asset_dir(project_id, apartment_uuid)
    if path.exists():
        shutil.rmtree(path, ignore_errors=True)
