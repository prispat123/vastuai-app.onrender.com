from __future__ import annotations

import json
from pathlib import Path
from typing import Any

RULES_FILE = Path(__file__).resolve().parents[1] / "config" / "vastu_rules.json"

DIRECTION_KEYS = {
    "Entrance": "entrance_direction",
    "Kitchen": "kitchen_direction",
    "Master Bedroom": "master_bedroom_direction",
    "Toilet": "toilet_direction",
    "Bathroom": "toilet_direction",
    "Pooja": "pooja_direction",
    "Prayer": "pooja_direction",
    "Living": "living_room_direction",
    "Balcony": "balcony_direction",
    "Staircase": "staircase_direction",
    "Children Bedroom": "children_bedroom_direction",
    "Guest Bedroom": "guest_bedroom_direction",
    "Dining": "dining_direction",
    "Brahmasthan": "brahmasthan_direction",
    "Central Zone": "brahmasthan_direction",
    "Underground Tank": "underground_tank_direction",
    "Overhead Tank": "overhead_tank_direction",
    "Parking": "parking_direction",
}


def load_rules() -> dict[str, dict[str, Any]]:
    return json.loads(RULES_FILE.read_text(encoding="utf-8"))


def _status(score: float) -> str:
    if score >= 8.5: return "Excellent"
    if score >= 7: return "Favourable"
    if score >= 5: return "Mixed"
    return "Needs attention"


def _grade(score: float) -> str:
    if score >= 9: return "A+"
    if score >= 8: return "A"
    if score >= 7: return "B+"
    if score >= 6: return "B"
    if score >= 5: return "C"
    return "D"


def _severity(score: float) -> str:
    if score <= 3: return "Critical"
    if score <= 5: return "High"
    if score < 7: return "Medium"
    return "Low"


def map_rooms_to_professional_fields(apartment: dict[str, Any]) -> dict[str, str]:
    fields: dict[str, str] = {}
    entrance = str(apartment.get("entrance_direction", "Unknown"))
    if entrance != "Unknown": fields["entrance_direction"] = entrance
    for room in apartment.get("rooms", []):
        if not isinstance(room, dict):
            continue
        room_type = str(room.get("room_type") or room.get("name") or "").strip()
        direction = str(room.get("direction") or "Unknown").strip()
        if direction == "Unknown":
            continue
        canonical = None
        low = room_type.lower()
        if "master" in low and "bed" in low: canonical = "master_bedroom_direction"
        elif "child" in low and "bed" in low: canonical = "children_bedroom_direction"
        elif "guest" in low and "bed" in low: canonical = "guest_bedroom_direction"
        elif "kitchen" in low: canonical = "kitchen_direction"
        elif "toilet" in low or "bath" in low or "wc" in low: canonical = "toilet_direction"
        elif "pooja" in low or "prayer" in low: canonical = "pooja_direction"
        elif "living" in low: canonical = "living_room_direction"
        elif "dining" in low: canonical = "dining_direction"
        elif "balcony" in low or "terrace" in low: canonical = "balcony_direction"
        elif "stair" in low: canonical = "staircase_direction"
        elif "parking" in low: canonical = "parking_direction"
        elif "overhead" in low and "tank" in low: canonical = "overhead_tank_direction"
        elif "underground" in low and "tank" in low: canonical = "underground_tank_direction"
        if canonical and canonical not in fields:
            fields[canonical] = direction
    return fields


def score_apartment(apartment: dict[str, Any]) -> dict[str, Any]:
    rules = load_rules()
    fields = map_rooms_to_professional_fields(apartment)
    details=[]; strengths=[]; cautions=[]; critical=[]
    weighted_total=0.0; total_weight=0.0
    for field, direction in fields.items():
        rule=rules.get(field)
        if not rule or direction not in rule.get("scores", {}):
            continue
        score=float(rule["scores"][direction]); weight=float(rule.get("weight",1.0))
        item={
            "field":field,"area":rule.get("label",field),"direction":direction,
            "score":score,"weight":weight,"weighted_score":round(score*weight,2),
            "status":_status(score),"severity":_severity(score),
            "preferred":rule.get("preferred",[]),"avoid":rule.get("avoid",[]),
            "rationale":rule.get("rationale",""),
            "structural_remedy":rule.get("remedies",{}).get("structural",""),
            "non_structural_remedy":rule.get("remedies",{}).get("non_structural",""),
        }
        details.append(item); weighted_total += score*weight; total_weight += weight
        if score >= 8: strengths.append(f"{item['area']} in {direction} is {item['status'].lower()}.")
        elif score < 7: cautions.append(f"{item['area']} in {direction} is rated {score:g}/10.")
        if score <= 5: critical.append(item)
    if not details:
        return {}
    overall=round(weighted_total/total_weight,1)
    coverage=round(len(details)/max(len(rules),1)*100,1)
    return {
        "score":overall,"percentage":round(overall*10,1),"grade":_grade(overall),
        "status":_status(overall),"details":details,"strengths":strengths,
        "cautions":cautions,"critical_issues":critical,"evaluated_count":len(details),
        "total_supported_factors":len(rules),"coverage":coverage,
        "confidence":"High" if len(details)>=8 and coverage>=65 else "Moderate" if len(details)>=5 else "Limited",
        "weighted_total":round(weighted_total,2),"total_weight":round(total_weight,2),
        "algorithm":"VastuAI Professional weighted rules v1",
    }
