from __future__ import annotations
import sqlite3
import uuid
from pathlib import Path
from typing import Iterable
from services.storage import database_path, migrate_legacy_data, remove_project_storage
from services.assets import persist_apartment_assets, remove_apartment_assets

migrate_legacy_data()
DB_PATH = database_path()
SCHEMA="""
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS projects(
 id INTEGER PRIMARY KEY AUTOINCREMENT, project_name TEXT NOT NULL,
 builder_name TEXT NOT NULL, location TEXT, architect TEXT,
 project_status TEXT NOT NULL DEFAULT 'Planning', notes TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS source_documents(
 id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL,
 original_name TEXT NOT NULL, stored_path TEXT NOT NULL, file_hash TEXT NOT NULL,
 page_count INTEGER NOT NULL DEFAULT 0, uploaded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(project_id,file_hash), FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS apartment_inventory(
 id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL, document_id INTEGER,
 page_number INTEGER, tower TEXT, floor TEXT, apartment_code TEXT, apartment_type TEXT,
 source_label TEXT, review_status TEXT NOT NULL DEFAULT 'Needs Review', page_image_path TEXT,
 extracted_text TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 apartment_uuid TEXT, layout_image_path TEXT, analysis_json_path TEXT, source_image_hash TEXT,
 FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE,
 FOREIGN KEY(document_id) REFERENCES source_documents(id) ON DELETE SET NULL);
CREATE TABLE IF NOT EXISTS page_reviews(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 project_id INTEGER NOT NULL,
 document_id INTEGER NOT NULL,
 page_number INTEGER NOT NULL,
 page_type TEXT NOT NULL,
 house_count INTEGER NOT NULL DEFAULT 0,
 analyse INTEGER NOT NULL DEFAULT 0,
 confidence REAL NOT NULL DEFAULT 0,
 reason TEXT,
 page_image_path TEXT,
 ocr_text TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(document_id,page_number),
 FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE,
 FOREIGN KEY(document_id) REFERENCES source_documents(id) ON DELETE CASCADE);
CREATE INDEX IF NOT EXISTS idx_page_reviews_project ON page_reviews(project_id);
CREATE INDEX IF NOT EXISTS idx_inventory_project ON apartment_inventory(project_id);
CREATE INDEX IF NOT EXISTS idx_inventory_tower_floor ON apartment_inventory(project_id,tower,floor);
"""
def connect():
 c=sqlite3.connect(DB_PATH); c.row_factory=sqlite3.Row; c.execute('PRAGMA foreign_keys=ON'); return c
def init_db():
 DB_PATH.parent.mkdir(parents=True,exist_ok=True)
 with connect() as c:
  c.executescript(SCHEMA)
  columns={row['name'] for row in c.execute('PRAGMA table_info(page_reviews)').fetchall()}
  if 'house_count' not in columns: c.execute('ALTER TABLE page_reviews ADD COLUMN house_count INTEGER NOT NULL DEFAULT 0')
  if 'confidence' not in columns: c.execute('ALTER TABLE page_reviews ADD COLUMN confidence REAL NOT NULL DEFAULT 0')
  inv_columns={row['name'] for row in c.execute('PRAGMA table_info(apartment_inventory)').fetchall()}
  for name, sql_type in [('apartment_uuid','TEXT'),('layout_image_path','TEXT'),('analysis_json_path','TEXT'),('source_image_hash','TEXT')]:
   if name not in inv_columns: c.execute(f'ALTER TABLE apartment_inventory ADD COLUMN {name} {sql_type}')
  rows=c.execute("SELECT id FROM apartment_inventory WHERE apartment_uuid IS NULL OR TRIM(apartment_uuid)='' ").fetchall()
  for row in rows: c.execute('UPDATE apartment_inventory SET apartment_uuid=? WHERE id=?',(str(uuid.uuid4()),row['id']))
  c.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_inventory_uuid ON apartment_inventory(apartment_uuid)')
def list_projects():
 with connect() as c:
  return c.execute("""SELECT p.*,COUNT(DISTINCT d.id) document_count,COUNT(i.id) apartment_count
  FROM projects p LEFT JOIN source_documents d ON d.project_id=p.id
  LEFT JOIN apartment_inventory i ON i.project_id=p.id GROUP BY p.id
  ORDER BY p.updated_at DESC,p.id DESC""").fetchall()
def get_project(pid):
 with connect() as c:return c.execute('SELECT * FROM projects WHERE id=?',(pid,)).fetchone()
def create_project(name,builder,location='',architect='',status='Planning',notes=''):
 with connect() as c:
  cur=c.execute("INSERT INTO projects(project_name,builder_name,location,architect,project_status,notes) VALUES(?,?,?,?,?,?)",
   (name.strip(),builder.strip(),location.strip(),architect.strip(),status,notes.strip())); return int(cur.lastrowid)
def update_project(pid,name,builder,location,architect,status,notes):
 with connect() as c:c.execute("UPDATE projects SET project_name=?,builder_name=?,location=?,architect=?,project_status=?,notes=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
  (name.strip(),builder.strip(),location.strip(),architect.strip(),status,notes.strip(),pid))
def delete_project(pid):
    # Backwards-compatible database-only delete. Prefer delete_project_permanently.
    with connect() as c:
        c.execute('DELETE FROM projects WHERE id=?',(pid,))


def delete_project_permanently(pid: int) -> dict:
    """Delete a project, its dependent database rows, and stored assets.

    Foreign-key cascades remove source documents, page reviews and apartment
    inventory. Project-scoped PDFs, rendered pages, AI cache, apartment images
    and JSON assets are then removed from persistent storage.
    """
    project = get_project(pid)
    if not project:
        raise ValueError('Project not found or already deleted.')
    project_name = str(project['project_name'])
    with connect() as c:
        c.execute('DELETE FROM projects WHERE id=?', (pid,))
    removed_paths = remove_project_storage(pid)
    return {
        'project_id': int(pid),
        'project_name': project_name,
        'removed_paths': removed_paths,
    }
def document_exists(pid,h):
 with connect() as c:return c.execute('SELECT 1 FROM source_documents WHERE project_id=? AND file_hash=?',(pid,h)).fetchone() is not None
def add_document(pid,name,path,h,pages):
 with connect() as c:
  cur=c.execute('INSERT INTO source_documents(project_id,original_name,stored_path,file_hash,page_count) VALUES(?,?,?,?,?)',(pid,name,path,h,pages)); return int(cur.lastrowid)
def list_documents(pid):
 with connect() as c:return c.execute('SELECT * FROM source_documents WHERE project_id=? ORDER BY uploaded_at DESC',(pid,)).fetchall()
def add_inventory_rows(rows:Iterable[dict]):
 prepared=[]
 for r in rows:
  apartment_uuid=str(r.get('apartment_uuid') or uuid.uuid4())
  assets=persist_apartment_assets(int(r['project_id']), apartment_uuid, r.get('page_image_path'), r.get('extracted_text'))
  prepared.append((r['project_id'],r.get('document_id'),r.get('page_number'),r.get('tower',''),r.get('floor',''),r.get('apartment_code',''),r.get('apartment_type',''),r.get('source_label',''),r.get('review_status','Needs Review'),r.get('page_image_path',''),r.get('extracted_text',''),apartment_uuid,assets['layout_image_path'],assets['analysis_json_path'],assets['source_image_hash']))
 if not prepared:return
 with connect() as c:
  c.executemany("""INSERT INTO apartment_inventory(project_id,document_id,page_number,tower,floor,apartment_code,apartment_type,source_label,review_status,page_image_path,extracted_text,apartment_uuid,layout_image_path,analysis_json_path,source_image_hash) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",prepared)
  c.execute('UPDATE projects SET updated_at=CURRENT_TIMESTAMP WHERE id=?',(prepared[0][0],))

def list_inventory(pid):
 with connect() as c:return c.execute("""SELECT i.*,d.original_name,p.project_name,p.builder_name
 FROM apartment_inventory i
 LEFT JOIN source_documents d ON d.id=i.document_id
 JOIN projects p ON p.id=i.project_id
 WHERE i.project_id=? ORDER BY i.tower,i.floor,i.apartment_code,i.page_number""",(pid,)).fetchall()
def replace_inventory(pid,records):
 with connect() as c:
  for r in records:
   c.execute("UPDATE apartment_inventory SET tower=?,floor=?,apartment_code=?,apartment_type=?,review_status=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND project_id=?",
    (str(r.get('tower','')).strip(),str(r.get('floor','')).strip(),str(r.get('apartment_code','')).strip(),str(r.get('apartment_type','')).strip(),str(r.get('review_status','Needs Review')).strip(),int(r['id']),pid))
  c.execute('UPDATE projects SET updated_at=CURRENT_TIMESTAMP WHERE id=?',(pid,))


def delete_inventory_for_document(project_id: int, document_id: int) -> None:
    with connect() as conn:
        conn.execute("DELETE FROM apartment_inventory WHERE project_id=? AND document_id=?", (project_id, document_id))

def delete_all_inventory(project_id: int) -> None:
    with connect() as conn:
        conn.execute("DELETE FROM apartment_inventory WHERE project_id=?", (project_id,))


def add_page_reviews(rows):
    if not rows: return
    payload=[(r['project_id'],r['document_id'],r['page_number'],r['page_type'],int(r.get('house_count',0) or 0),1 if r.get('analyse') else 0,float(r.get('confidence',0) or 0),r.get('reason',''),r.get('page_image_path',''),r.get('ocr_text','')) for r in rows]
    with connect() as c:
        c.executemany("""INSERT OR REPLACE INTO page_reviews(project_id,document_id,page_number,page_type,house_count,analyse,confidence,reason,page_image_path,ocr_text) VALUES(?,?,?,?,?,?,?,?,?,?)""",payload)

def list_page_reviews(pid):
    with connect() as c:
        return c.execute("""SELECT r.*,d.original_name FROM page_reviews r JOIN source_documents d ON d.id=r.document_id WHERE r.project_id=? ORDER BY d.id,r.page_number""",(pid,)).fetchall()

def delete_page_reviews_for_document(pid,document_id):
    with connect() as c:c.execute('DELETE FROM page_reviews WHERE project_id=? AND document_id=?',(pid,document_id))

def delete_inventory_rows(pid,row_ids):
    ids=[int(x) for x in row_ids if x is not None]
    if not ids:return
    marks=','.join('?' for _ in ids)
    with connect() as c:
        uuids=[r['apartment_uuid'] for r in c.execute(f'SELECT apartment_uuid FROM apartment_inventory WHERE project_id=? AND id IN ({marks})',[pid,*ids]).fetchall()]
        c.execute(f'DELETE FROM apartment_inventory WHERE project_id=? AND id IN ({marks})',[pid,*ids])
        c.execute('UPDATE projects SET updated_at=CURRENT_TIMESTAMP WHERE id=?',(pid,))
    for apartment_uuid in uuids:
        if apartment_uuid: remove_apartment_assets(pid,apartment_uuid)


def ensure_apartment_assets(pid: int) -> int:
    """Backfill/repair persistent layout and JSON assets for existing records."""
    repaired=0
    with connect() as c:
        rows=c.execute('SELECT * FROM apartment_inventory WHERE project_id=?',(pid,)).fetchall()
        for row in rows:
            apartment_uuid=row['apartment_uuid'] or str(uuid.uuid4())
            layout=Path(row['layout_image_path']) if row['layout_image_path'] else None
            analysis=Path(row['analysis_json_path']) if row['analysis_json_path'] else None
            if layout and layout.exists() and analysis and analysis.exists() and row['apartment_uuid']:
                continue
            assets=persist_apartment_assets(pid,apartment_uuid,row['page_image_path'],row['extracted_text'])
            c.execute('UPDATE apartment_inventory SET apartment_uuid=?,layout_image_path=?,analysis_json_path=?,source_image_hash=? WHERE id=?',
                      (apartment_uuid,assets['layout_image_path'],assets['analysis_json_path'],assets['source_image_hash'],row['id']))
            repaired+=1
    return repaired


def project_snapshot(pid: int) -> dict:
    project = get_project(pid)
    if not project:
        raise ValueError("Project not found")
    with connect() as c:
        documents = [dict(r) for r in c.execute("SELECT * FROM source_documents WHERE project_id=? ORDER BY id", (pid,)).fetchall()]
        inventory = [dict(r) for r in c.execute("SELECT * FROM apartment_inventory WHERE project_id=? ORDER BY id", (pid,)).fetchall()]
        page_reviews = [dict(r) for r in c.execute("SELECT * FROM page_reviews WHERE project_id=? ORDER BY document_id,page_number", (pid,)).fetchall()]
    return {"schema_version": 1, "project": dict(project), "documents": documents, "inventory": inventory, "page_reviews": page_reviews}


def import_project_snapshot(snapshot: dict) -> int:
    project = snapshot.get("project") or {}
    name = str(project.get("project_name") or "Imported Project")
    builder = str(project.get("builder_name") or "Unknown Builder")
    pid = create_project(name, builder, str(project.get("location") or ""), str(project.get("architect") or ""), str(project.get("project_status") or "Planning"), str(project.get("notes") or ""))
    old_to_new_doc = {}
    with connect() as c:
        for doc in snapshot.get("documents", []):
            cur = c.execute("""INSERT INTO source_documents(project_id,original_name,stored_path,file_hash,page_count,uploaded_at) VALUES(?,?,?,?,?,COALESCE(?,CURRENT_TIMESTAMP))""",
                (pid, str(doc.get("original_name") or "Imported document"), str(doc.get("stored_path") or ""), str(doc.get("file_hash") or f"imported-{pid}-{doc.get('id','x')}") , int(doc.get("page_count") or 0), doc.get("uploaded_at")))
            old_to_new_doc[doc.get("id")] = int(cur.lastrowid)
        for row in snapshot.get("inventory", []):
            c.execute("""INSERT INTO apartment_inventory(project_id,document_id,page_number,tower,floor,apartment_code,apartment_type,source_label,review_status,page_image_path,extracted_text,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (pid, old_to_new_doc.get(row.get("document_id")), row.get("page_number"), str(row.get("tower") or ""), str(row.get("floor") or ""), str(row.get("apartment_code") or ""), str(row.get("apartment_type") or ""), str(row.get("source_label") or "Imported data"), str(row.get("review_status") or "Needs Review"), str(row.get("page_image_path") or ""), str(row.get("extracted_text") or ""), row.get("created_at") or "CURRENT_TIMESTAMP", row.get("updated_at") or "CURRENT_TIMESTAMP"))
        for row in snapshot.get("page_reviews", []):
            docid = old_to_new_doc.get(row.get("document_id"))
            if not docid:
                continue
            c.execute("""INSERT INTO page_reviews(project_id,document_id,page_number,page_type,house_count,analyse,confidence,reason,page_image_path,ocr_text,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,COALESCE(?,CURRENT_TIMESTAMP))""",
                (pid, docid, int(row.get("page_number") or 0), str(row.get("page_type") or "Unknown"), int(row.get("house_count") or 0), int(bool(row.get("analyse"))), float(row.get("confidence") or 0), str(row.get("reason") or ""), str(row.get("page_image_path") or ""), str(row.get("ocr_text") or ""), row.get("created_at")))
    return pid


def import_inventory_csv(pid: int, records: list[dict]) -> int:
    import json

    rows=[]
    for r in records:
        extracted = r.get("Vastu JSON", r.get("extracted_text", ""))
        if not str(extracted or "").strip():
            # Permit recovery from the human-readable direction columns even when
            # the full Vastu JSON column was removed during spreadsheet editing.
            rooms = []
            raw_rooms = r.get("Rooms JSON", "")
            try:
                candidate = json.loads(str(raw_rooms)) if str(raw_rooms).strip() else []
                if isinstance(candidate, list): rooms = candidate
            except (TypeError, ValueError, json.JSONDecodeError):
                room_map_raw = r.get("Room Directions", "")
                try:
                    room_map = json.loads(str(room_map_raw)) if str(room_map_raw).strip() else {}
                    if isinstance(room_map, dict):
                        rooms = [{"name": str(k), "direction": str(v), "confidence": 0.0} for k,v in room_map.items()]
                except (TypeError, ValueError, json.JSONDecodeError):
                    rooms = []
            extracted = json.dumps({"apartment": {
                "tower": r.get("Tower", r.get("tower", "")),
                "floor": r.get("Floor", r.get("floor", "")),
                "apartment_code": r.get("Apartment", r.get("apartment_code", "")),
                "apartment_type": r.get("Type", r.get("apartment_type", "")),
                "north_direction": r.get("North Direction", "Unknown"),
                "entrance_direction": r.get("Entrance Direction", "Unknown"),
                "rooms": rooms,
                "confidence": r.get("Vastu Confidence", 0),
                "notes": r.get("Vastu Notes", ""),
            }}, ensure_ascii=False)
        rows.append({
            "project_id": pid,
            "tower": r.get("Tower", r.get("tower", "")),
            "floor": r.get("Floor", r.get("floor", "")),
            "apartment_code": r.get("Apartment", r.get("apartment_code", "")),
            "apartment_type": r.get("Type", r.get("apartment_type", "")),
            "review_status": r.get("Status", r.get("review_status", "Needs Review")),
            "page_number": r.get("Page", r.get("page_number")),
            "source_label": r.get("Source PDF", r.get("source_label", "Imported CSV")),
            "extracted_text": extracted,
        })
    add_inventory_rows(rows)
    return len(rows)


def update_apartment_extraction(project_id: int, apartment_id: int, payload: dict) -> None:
    """Persist a refreshed room/direction extraction in DB and permanent JSON asset."""
    import json
    with connect() as conn:
        row = conn.execute(
            "SELECT * FROM apartment_inventory WHERE project_id=? AND id=?",
            (project_id, apartment_id),
        ).fetchone()
        if not row:
            raise ValueError("Apartment record not found")
        text = json.dumps(payload, ensure_ascii=False)
        apartment_uuid = row["apartment_uuid"] or str(uuid.uuid4())
        assets = persist_apartment_assets(
            project_id,
            apartment_uuid,
            row["layout_image_path"] or row["page_image_path"],
            payload,
        )
        conn.execute(
            """UPDATE apartment_inventory
               SET extracted_text=?, apartment_uuid=?, layout_image_path=?,
                   analysis_json_path=?, source_image_hash=?, updated_at=CURRENT_TIMESTAMP
               WHERE project_id=? AND id=?""",
            (
                text,
                apartment_uuid,
                assets["layout_image_path"],
                assets["analysis_json_path"],
                assets["source_image_hash"],
                project_id,
                apartment_id,
            ),
        )
        conn.execute("UPDATE projects SET updated_at=CURRENT_TIMESTAMP WHERE id=?", (project_id,))
