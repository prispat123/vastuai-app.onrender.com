from io import BytesIO
import pandas as pd
COLS=['tower','floor','apartment_code','apartment_type','review_status','original_name','page_number']
def inventory_dataframe(rows):
 data=[dict(r) for r in rows]
 if not data:return pd.DataFrame(columns=['Tower','Floor','Apartment','Type','Status','Source PDF','Page'])
 df=pd.DataFrame(data)
 for c in COLS:
  if c not in df:df[c]=''
 return df[COLS].rename(columns={'tower':'Tower','floor':'Floor','apartment_code':'Apartment','apartment_type':'Type','review_status':'Status','original_name':'Source PDF','page_number':'Page'})
def to_excel_bytes(df):
 out=BytesIO()
 with pd.ExcelWriter(out,engine='openpyxl') as w:
  df.to_excel(w,index=False,sheet_name='Apartment Inventory'); ws=w.book['Apartment Inventory']; ws.freeze_panes='A2'
  for cells in ws.columns:
   ws.column_dimensions[cells[0].column_letter].width=min(max(len(str(c.value or '')) for c in cells)+2,40)
 return out.getvalue()
