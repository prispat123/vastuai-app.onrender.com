from __future__ import annotations

import os
import shutil
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parents[1]


def data_root() -> Path:
    """Return a stable user-data folder that is independent of the code/build folder."""
    configured = os.getenv("VASTUAI_DATA_DIR", "").strip()
    root = Path(configured).expanduser() if configured else Path.home() / "VastuAI_Builder_Data"
    root.mkdir(parents=True, exist_ok=True)
    return root.resolve()


def database_path() -> Path:
    path = data_root() / "database" / "vastuai_builder.db"
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def uploads_root() -> Path:
    path = data_root() / "uploads"
    path.mkdir(parents=True, exist_ok=True)
    return path


def exports_root() -> Path:
    path = data_root() / "exports"
    path.mkdir(parents=True, exist_ok=True)
    return path


def migrate_legacy_data() -> None:
    """Copy the old build-local database once, so upgrades do not lose prior work."""
    target = database_path()
    legacy = APP_ROOT / "data" / "vastuai_builder.db"
    if not target.exists() and legacy.exists():
        shutil.copy2(legacy, target)


def remove_project_storage(project_id: int) -> list[str]:
    """Permanently remove all filesystem assets belonging to one project.

    Only project-scoped folders inside the configured VASTUAI_DATA_DIR are
    touched. The shared database and unrelated projects are never removed.
    """
    removed: list[str] = []
    candidates = [
        data_root() / "projects" / f"project_{int(project_id)}",
        uploads_root() / f"project_{int(project_id)}",
        exports_root() / f"project_{int(project_id)}",
    ]
    root = data_root().resolve()
    for candidate in candidates:
        resolved = candidate.resolve()
        if root not in resolved.parents:
            raise ValueError(f"Refusing to delete path outside the data directory: {resolved}")
        if resolved.exists():
            shutil.rmtree(resolved)
            removed.append(str(resolved))
    return removed
