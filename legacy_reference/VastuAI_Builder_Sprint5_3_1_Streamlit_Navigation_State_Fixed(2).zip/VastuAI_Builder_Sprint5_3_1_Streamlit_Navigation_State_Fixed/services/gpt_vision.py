from __future__ import annotations

import base64
import hashlib
import json
import os
import time
from dataclasses import dataclass
from services.professional_vastu import score_apartment
from pathlib import Path
from typing import Any

try:
    from dotenv import load_dotenv
except ImportError:  # Tests can import helpers before dependencies are installed.
    def load_dotenv(*args, **kwargs):
        return False

load_dotenv(Path(__file__).resolve().parents[1] / ".env")

PAGE_TYPES = {
    "Cover",
    "Site Plan",
    "Tower Divider",
    "Typical Floor",
    "Multi-Apartment Floor",
    "Single Apartment",
    "Amenities",
    "Elevation",
    "Services Drawing",
    "Structural Drawing",
    "Blank",
    "Other",
    "Unknown",
}


@dataclass(frozen=True)
class VisionSettings:
    classifier_model: str = os.getenv("OPENAI_CLASSIFIER_MODEL", "gpt-5-mini")
    detail_model: str = os.getenv("OPENAI_VISION_MODEL", "gpt-5")
    max_retries: int = int(os.getenv("OPENAI_MAX_RETRIES", "3"))


def api_key_available() -> bool:
    return bool(os.getenv("OPENAI_API_KEY", "").strip())


def image_sha256(image_path: Path) -> str:
    return hashlib.sha256(image_path.read_bytes()).hexdigest()


def _data_url(image_path: Path) -> str:
    suffix = image_path.suffix.lower()
    mime = "image/jpeg" if suffix in {".jpg", ".jpeg"} else "image/png"
    encoded = base64.b64encode(image_path.read_bytes()).decode("ascii")
    return f"data:{mime};base64,{encoded}"


def _extract_json(text: str) -> dict[str, Any]:
    value = (text or "").strip()
    if value.startswith("```"):
        value = value.removeprefix("```json").removeprefix("```")
        if value.endswith("```"):
            value = value[:-3]
        value = value.strip()
    start, end = value.find("{"), value.rfind("}")
    if start < 0 or end < start:
        raise ValueError("The model response did not contain a JSON object.")
    parsed = json.loads(value[start : end + 1])
    if not isinstance(parsed, dict):
        raise ValueError("Expected a JSON object from the vision model.")
    return parsed


def _request_json(*, model: str, prompt: str, image_path: Path, detail: str, max_retries: int) -> tuple[dict[str, Any], str]:
    if not api_key_available():
        raise RuntimeError("OPENAI_API_KEY is missing. Add it to the .env file and restart the app.")

    try:
        from openai import OpenAI
    except ImportError as exc:
        raise RuntimeError("The openai package is missing. Run: pip install -r requirements.txt") from exc
    client = OpenAI()
    last_error: Exception | None = None
    for attempt in range(max_retries):
        try:
            response = client.responses.create(
                model=model,
                input=[
                    {
                        "role": "user",
                        "content": [
                            {"type": "input_text", "text": prompt},
                            {"type": "input_image", "image_url": _data_url(image_path), "detail": detail},
                        ],
                    }
                ],
            )
            raw = response.output_text
            return _extract_json(raw), raw
        except Exception as exc:  # SDK/network errors are surfaced after retries
            last_error = exc
            if attempt + 1 < max_retries:
                time.sleep(2**attempt)
    raise RuntimeError(f"Vision request failed after {max_retries} attempts: {last_error}") from last_error


CLASSIFIER_PROMPT = """
You classify ONE page from a residential real-estate brochure or architectural PDF.
Return JSON only, with exactly these keys:
{
  "page_type": "one allowed value",
  "house_count": 0,
  "analyse": false,
  "confidence": 0.0,
  "reason": "brief factual reason"
}
Allowed page_type values:
Cover, Site Plan, Tower Divider, Typical Floor, Multi-Apartment Floor,
Single Apartment, Amenities, Elevation, Services Drawing, Structural Drawing,
Blank, Other, Unknown.

Critical policy:
- analyse=true ONLY when the page shows exactly ONE complete apartment/house layout.
- If it shows two or more separate dwelling layouts, classify Multi-Apartment Floor and analyse=false.
- A typical floor/core plan with several flats is not a single apartment even if one unit is highlighted.
- Do not count legends, north arrows, inset location maps, furniture icons or duplicated title graphics as houses.
- If uncertain whether there is exactly one complete dwelling, set analyse=false and page_type=Unknown.
""".strip()


DETAIL_PROMPT = """
You are analysing ONE complete residential apartment floor plan using the exact
VastuAI Professional direction-detection method. Return JSON only.

Hard rules:
1. Detect and use only a clearly printed North arrow/compass. Never infer North from page orientation,
   text orientation, road position, sunlight, architectural convention or assumptions.
2. If North is absent, cropped or ambiguous, set north_detected=false and all directions to Unknown.
3. Read visible room labels and identify only rooms genuinely visible in this apartment.
4. Determine each room direction geometrically relative to the confirmed North reference and the
   room centre. Use only North, North-East, East, South-East, South, South-West, West,
   North-West, Centre, Unknown.
5. Provide normalized bbox [x1,y1,x2,y2] and confidence 0..1. Do not invent rooms.
6. Preserve printed tower, floor, apartment number and BHK exactly. Never interpret grid labels
   such as X10/Y11 as apartment numbers.

Return exactly:
{
  "tower":"", "floor":"", "apartment_code":"", "apartment_type":"",
  "north_detected":true, "north_source":"image|none", "north_confidence":0.0,
  "north_description":"", "vision_quality_score":0, "issues":[], "extracted_text":[],
  "entrance_direction":"Unknown",
  "rooms":[
    {"room_id":"room-1","name":"Living Room","room_type":"Living Room",
     "direction":"North-East","zone":"North-East","confidence":0.0,
     "bbox":[0.0,0.0,0.0,0.0],"label_text":"LIVING"}
  ],
  "confidence":0.0,"notes":""
}
""".strip()


def classify_page(image_path: Path, settings: VisionSettings | None = None) -> tuple[dict[str, Any], str]:
    settings = settings or VisionSettings()
    data, raw = _request_json(
        model=settings.classifier_model,
        prompt=CLASSIFIER_PROMPT,
        image_path=image_path,
        detail="low",
        max_retries=settings.max_retries,
    )
    page_type = str(data.get("page_type", "Unknown")).strip()
    if page_type not in PAGE_TYPES:
        page_type = "Unknown"
    try:
        house_count = max(0, int(data.get("house_count", 0)))
    except (TypeError, ValueError):
        house_count = 0
    confidence = min(1.0, max(0.0, float(data.get("confidence", 0.0) or 0.0)))
    analyse = bool(data.get("analyse")) and page_type == "Single Apartment" and house_count == 1
    return {
        "page_type": page_type,
        "house_count": house_count,
        "analyse": analyse,
        "confidence": confidence,
        "reason": str(data.get("reason", "")).strip() or "No reason supplied.",
    }, raw


def analyse_single_apartment(image_path: Path, settings: VisionSettings | None = None) -> tuple[dict[str, Any], str]:
    settings = settings or VisionSettings()
    data, raw = _request_json(model=settings.detail_model, prompt=DETAIL_PROMPT,
                              image_path=image_path, detail="high", max_retries=settings.max_retries)
    allowed = {"North","North-East","East","South-East","South","South-West","West","North-West","Centre","Unknown"}
    north_detected=bool(data.get("north_detected", str(data.get("north_direction", "Unknown")) != "Unknown"))
    raw_rooms=data.get("rooms") if isinstance(data.get("rooms"),list) else []
    rooms=[]
    for index, room in enumerate(raw_rooms,1):
        if not isinstance(room,dict): continue
        name=str(room.get("name","")).strip()
        if not name: continue
        direction=str(room.get("direction","Unknown")).strip()
        if not north_detected or direction not in allowed: direction="Unknown"
        try: confidence=max(0.0,min(1.0,float(room.get("confidence",0) or 0)))
        except Exception: confidence=0.0
        box=room.get("bbox")
        if isinstance(box,list) and len(box)==4:
            try:
                x1,y1,x2,y2=[max(0.0,min(1.0,float(v))) for v in box]
                bbox={"x":x1,"y":y1,"width":max(0.0,x2-x1),"height":max(0.0,y2-y1)}
            except Exception: bbox={"x":0.0,"y":0.0,"width":0.0,"height":0.0}
        elif isinstance(box,dict):
            def cl(v):
                try:return max(0.0,min(1.0,float(v or 0)))
                except Exception:return 0.0
            bbox={k:cl(box.get(k,0)) for k in ("x","y","width","height")}
        else: bbox={"x":0.0,"y":0.0,"width":0.0,"height":0.0}
        centre={"x":bbox["x"]+bbox["width"]/2,"y":bbox["y"]+bbox["height"]/2}
        rooms.append({"room_id":str(room.get("room_id") or f"room-{index}"),"name":name,
                      "room_type":str(room.get("room_type") or name).strip(),"direction":direction,
                      "zone":direction,"confidence":confidence,"bbox":bbox,"centre":centre,
                      "label_text":str(room.get("label_text") or "").strip()})
    apt_type=str(data.get("apartment_type","")).strip().replace(",",".").replace(" ","")
    if apt_type.lower().endswith("bhk"): apt_type=apt_type[:-3]+"BHK"
    entrance=str(data.get("entrance_direction","Unknown")).strip()
    if not north_detected or entrance not in allowed: entrance="Unknown"
    apartment={
        "tower":str(data.get("tower","")).strip(),"floor":str(data.get("floor","")).strip(),
        "apartment_code":str(data.get("apartment_code","")).strip(),"apartment_type":apt_type,
        "north_detected":north_detected,"north_source":str(data.get("north_source","none")),
        "north_confidence":max(0.0,min(1.0,float(data.get("north_confidence",0) or 0))),
        "north_description":str(data.get("north_description","")).strip(),
        "north_direction":"North" if north_detected else "Unknown",
        "entrance_direction":entrance,"rooms":rooms,
        "vision_quality_score":int(data.get("vision_quality_score",0) or 0),
        "issues":[str(x) for x in data.get("issues",[]) if str(x).strip()],
        "extracted_text":[str(x) for x in data.get("extracted_text",[]) if str(x).strip()],
        "confidence":max(0.0,min(1.0,float(data.get("confidence",0) or 0))),
        "notes":str(data.get("notes","")).strip(),
        "direction_algorithm":"VastuAI Professional vision method",
    }
    apartment["vastu_result"]=score_apartment(apartment)
    return apartment, raw

