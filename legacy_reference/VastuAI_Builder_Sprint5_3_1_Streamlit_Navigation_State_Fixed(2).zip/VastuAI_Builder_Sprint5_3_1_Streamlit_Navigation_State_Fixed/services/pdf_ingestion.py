from __future__ import annotations

import hashlib
import json
from pathlib import Path

import fitz
from PIL import Image

from services.gpt_vision import VisionSettings, analyse_single_apartment, classify_page, image_sha256


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _read_cache(cache_path: Path) -> dict | None:
    try:
        return json.loads(cache_path.read_text(encoding="utf-8")) if cache_path.exists() else None
    except (OSError, json.JSONDecodeError):
        return None


def _write_cache(cache_path: Path, payload: dict) -> None:
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    cache_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def process_pdf_bytes(
    data: bytes,
    output_dir: Path,
    source_name: str,
    settings: VisionSettings | None = None,
    progress_callback=None,
) -> tuple[int, list[dict], list[dict]]:
    """Render a PDF and use GPT-5 vision to classify every page.

    A detailed vision request is made only for pages confidently classified as one
    complete apartment. Results are cached by image hash to avoid repeat API cost.
    """
    settings = settings or VisionSettings()
    output_dir.mkdir(parents=True, exist_ok=True)
    cache_dir = output_dir.parent / "ai_cache"
    document = fitz.open(stream=data, filetype="pdf")
    inventory_rows: list[dict] = []
    page_rows: list[dict] = []
    total = len(document)

    for index, page in enumerate(document):
        page_number = index + 1
        if progress_callback:
            progress_callback(page_number, total, f"Rendering page {page_number}")
        pixmap = page.get_pixmap(matrix=fitz.Matrix(2.0, 2.0), alpha=False)
        image_path = output_dir / f"page_{page_number:03d}.jpg"
        # PyMuPDF versions differ in support for JPEG quality arguments.
        # Convert through Pillow so PDF processing works consistently on Windows.
        mode = "RGB" if pixmap.n < 4 else "RGBA"
        image = Image.frombytes(mode, (pixmap.width, pixmap.height), pixmap.samples)
        if image.mode != "RGB":
            image = image.convert("RGB")
        image.save(image_path, format="JPEG", quality=88, optimize=True)

        digest = image_sha256(image_path)
        classification_cache = cache_dir / f"{digest}_classify.json"
        cached = _read_cache(classification_cache)
        if cached:
            classification = cached["result"]
            classifier_raw = cached.get("raw", "")
        else:
            if progress_callback:
                progress_callback(page_number, total, f"Classifying page {page_number} with GPT-5 vision")
            classification, classifier_raw = classify_page(image_path, settings)
            _write_cache(classification_cache, {"result": classification, "raw": classifier_raw})

        detail = None
        detail_raw = ""
        if classification["analyse"]:
            detail_cache = cache_dir / f"{digest}_detail.json"
            cached_detail = _read_cache(detail_cache)
            if cached_detail:
                detail = cached_detail["result"]
                detail_raw = cached_detail.get("raw", "")
            else:
                if progress_callback:
                    progress_callback(page_number, total, f"Extracting apartment details from page {page_number}")
                detail, detail_raw = analyse_single_apartment(image_path, settings)
                _write_cache(detail_cache, {"result": detail, "raw": detail_raw})

        page_rows.append(
            {
                "page_number": page_number,
                "page_type": classification["page_type"],
                "house_count": classification["house_count"],
                "analyse": classification["analyse"],
                "confidence": classification["confidence"],
                "reason": classification["reason"],
                "page_image_path": str(image_path),
                "ocr_text": classifier_raw[:16000],
            }
        )

        if detail is not None:
            inventory_rows.append(
                {
                    "tower": detail["tower"],
                    "floor": detail["floor"],
                    "apartment_code": detail["apartment_code"],
                    "apartment_type": detail["apartment_type"],
                    "review_status": "Needs Review",
                    "page_number": page_number,
                    "source_label": f"{source_name} — Page {page_number}",
                    "page_image_path": str(image_path),
                    "extracted_text": json.dumps(
                        {
                            "classification": classification,
                            "apartment": detail,
                            "raw": detail_raw,
                        },
                        ensure_ascii=False,
                    )[:16000],
                }
            )

    document.close()
    if progress_callback:
        progress_callback(total, total, f"Completed {total} page(s)")
    return total, inventory_rows, page_rows
