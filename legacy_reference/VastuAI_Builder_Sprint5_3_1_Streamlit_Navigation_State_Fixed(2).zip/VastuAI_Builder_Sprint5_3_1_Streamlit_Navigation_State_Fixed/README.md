# VastuAI Builder Sprint 4.0 — Stable Project Management

This build keeps the GPT-5 Vision, room-direction extraction, persistent apartment images, JSON/CSV backups, and no-repeat API cache from Sprint 3.1. It adds safe project deletion for clean test runs and project lifecycle management.

## New: permanent project deletion

On the **Projects** screen, click **Delete** beside a project. The application requires:

1. The exact project name.
2. An irreversible-deletion acknowledgement.

A JSON backup can be downloaded directly from the confirmation panel before deletion.

Deletion removes only that project's:

- Database records and dependent rows
- Uploaded source PDFs
- Rendered page images
- Page-classification and detailed-analysis cache
- Persistent apartment layout images
- Saved apartment analysis JSON
- Project-scoped exports

Other projects and the shared application database remain intact.

## Clean run for Avinya

Delete the previous Avinya project from **Projects**, create a fresh project, upload the source PDF, and select **Process PDFs**. Extracted rooms, directions, layouts, and GPT JSON are then persisted under `VASTUAI_DATA_DIR` and will load in later builds without repeat API calls.

## Setup

Copy `.env.example` to `.env`, add the existing OpenAI API key, then run:

```powershell
pip install -r requirements.txt
python launch_app.py
```

## Sprint 4.1: Professional analysis parity
Single-apartment pages now use the same strict north-reference, room-direction normalization,
and weighted Vastu rules used by VastuAI Professional. Builder reporting remains project-centric.
The saved apartment JSON contains `direction_algorithm` and `vastu_result`, and CSV exports include
Vastu Score, Grade and Status. Existing saved projects remain loadable; re-analysis is required only
for apartments whose earlier direction extraction was inaccurate.

## Sprint 5.0 — complete Vastu analysis and reporting

A visible **Vastu Analysis & Reports** workspace now runs the Professional weighted rules engine on saved directions without an OpenAI call. It includes project scorecards, room-by-room assessment, strengths, concerns, recommendations, analysis coverage/confidence, individual apartment PDF reports, and a complete builder/project PDF report. Apartments with unresolved North remain explicitly unavailable rather than being scored from page orientation.

## Sprint 5.1 — Shared Engine and Manual Review

- `shared_analysis/engine.py` is the single canonical pipeline for both Builder and Professional.
- `ui_adapters/builder.py` and `ui_adapters/professional.py` expose the same engine to separate UIs and reporting layers.
- Manual North override supports Top, Right, Bottom and Left page orientations.
- A manual North correction recalculates room directions geometrically from saved room centres and reruns Vastu analysis without an OpenAI call.
- Entrance is visible and editable in the Room Directions workspace.
- North/entrance sources and override audit records are persisted and included in reports.

## Sprint 5.2 visual correction workspace

- The selected apartment layout is displayed beside the North and entrance controls.
- Recalculate directions after confirming page North.
- Review, add, delete, or manually correct room directions in an editable table while the plan remains visible.
- Save corrections and run the shared Vastu engine immediately without another GPT call.
- Updated analysis automatically flows into apartment and project PDF reports.

## Sprint 5.3 — Navigation and screen-flow corrections

- Replaced transient Streamlit tabs with a persistent project-workspace navigator.
- Saving North and entrance now remains on **Room Directions & Manual Review**, with the recalculated room table immediately available.
- Removed the redundant **Save room corrections** button.
- The single primary action is now **Save room corrections & run Vastu analysis**.
- Completing apartment review navigates directly to **Vastu Analysis & Reports**.
- Completing PDF processing or document rebuild navigates to **Page Review**.
- Standardized project workspace screen headers.
- Added navigation regression tests.


## Sprint 5.3.1 navigation hotfix

Project navigation now uses a staged pending destination before the workspace radio widget is created. This fixes `StreamlitAPIException: st.session_state.project_section_<id> cannot be modified after the widget ... is instantiated` when saving manual review, running Vastu analysis, processing PDFs, or rebuilding inventory.
