"""UI-specific adapters over the shared analysis engine."""
